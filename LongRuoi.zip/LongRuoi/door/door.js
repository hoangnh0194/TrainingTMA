const StrDay = ["Chủ nhật", "Thứ 2", "Thứ 3", "Thứ 4", "Thứ 5", "Thứ 6", "Thứ 7"];
const PassFeedBack = ["Mật khẩu sai", "Mật khẩu đúng, cửa chuẩn bị được mở", "Lỗi: Mật khẫu cũ chưa đúng", "Mật khẩu mới trùng", "Đổi mật khẩu thành công", "MK bị khóa", "Cửa đã mở, không cần mở nữa", "Cửa đang đóng", "Cửa đã đóng, không cần đóng nữa"];
const StateDoor = ["Đang đóng", "Đang mở", "Bị đột nhập"];
var DoorSecurityState = '0';


function createXMLHttpRequest() {
    if (window.ActiveXObject) {
        xmlHttp = new ActiveXObject("Microsoft.XMLHTTP");
    } else if (window.XMLHttpRequest) {
        try {
            xmlHttp = new XMLHttpRequest();
        } catch (e) {}
    }
}

function startRequest(url, flag_reload) {
    createXMLHttpRequest();
    xmlHttp.onreadystatechange = handleStateChange;
    xmlHttp.open("GET", url, true);
    xmlHttp.send(null);
    if (flag_reload == 1) {
        window.setTimeout("startRequest('statedoor.html',1);", 1000);
    }
}

function handleStateChange() {
    if (xmlHttp.readyState == 4) {
        if (xmlHttp.status == 200) {
            strResponse = xmlHttp.responseText;

            if (strResponse.substr(0, 6) == "<!--#s") {
                DoorSecurityState = strResponse.substr(9, 1);
                SwitchImgDoorState(DoorSecurityState);
                var tem = strResponse.substr(10, 4);
                if (tem != "0000") {
                    document.getElementById("TimoutOpen").innerHTML = "Cửa đóng lại sau " + tem + " giây nữa";
                } else {
                    document.getElementById("TimoutOpen").innerHTML = "";
                }
                document.getElementById("TimeOnline").innerHTML = strResponse.substr(14, 2) + ":" + strResponse.substr(16, 2) + ":" + strResponse.substr(18, 2) + "   " + StrDay[parseInt(strResponse.substr(20, 1)) - 1] + " " + strResponse.substr(21, 2) + "-" + strResponse.substr(23, 2) + "-" + strResponse.substr(25, 4);
            } else if (strResponse.substr(0, 6) == "<!--#p") {
                tem = strResponse.substr(9, 1);
                if (tem == "0") {
                    Mymsg("Mật khẩu sai, Bạn còn " + strResponse.substr(10, 1) + " lần nhập");
                } else if (tem == "1" || tem == "2" || tem == "4" || tem == "6" || tem == "7" || tem == "8") {
                    if (tem == "8") //xoa thoi gian dem nguoc open
                    {
                        document.getElementById("TimoutOpen").innerHTML = "";
                    }
                    Mymsg(PassFeedBack[parseInt(strResponse.substr(9, 1))]);
                } else if (tem == "3") {
                    Mymsg("Lỗi : Thay đổi không thành công, mật khẩu vừa nhập trùng với 1 trong " + strResponse.substr(10, 1) + " mật khẩu cũ gần nhất");
                } else if (tem == "5") {
                    Mymsg("Mật khẩu bị khóa trong vòng " + strResponse.substr(11, 4) + " giây nữa");
                }
            }
        }
    }
}