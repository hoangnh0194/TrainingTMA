var RelayState = ['0', '0', '0', '0'];
const StrDay = ["Chủ nhật", "Thứ 2", "Thứ 3", "Thứ 4", "Thứ 5", "Thứ 6", "Thứ 7"];
const StrAlarmResuilt = ["Giá trị không hợp lệ", "Lỗi cú pháp", "Đã tồn Tại, Không thể thêm", "Đã đầy, Không thể thêm", "Giá trị On phải khác giá trị Off", "Giá trị Off phải khác giá trị On"];
var xmlHttp;
var strResponse;

function createXMLHttpRequest() {
    if (window.ActiveXObject) {
        xmlHttp = new ActiveXObject("Microsoft.XMLHTTP");
    } else if (window.XMLHttpRequest) {
        try {
            xmlHttp = new XMLHttpRequest();
        } catch (e) {}
    }
}

function startRequest(url, flag_reload) {
    createXMLHttpRequest();
    xmlHttp.onreadystatechange = handleStateChange;
    xmlHttp.open("GET", url, true);
    xmlHttp.send(null);
    if (flag_reload == 1) {
        window.setTimeout("startRequest('update.shtml',1);", 1000);
    }
}

function handleStateChange() {
    if (xmlHttp.readyState == 4) {
        if (xmlHttp.status == 200) {
            strResponse = xmlHttp.responseText;

            if (strResponse.substr(0, 6) == "<!--#u") {
                //alert(strResponse);
                var i = 0,
                    k = 0;
                var StrTem;
                for (i = 0; i < 4; i++) {
                    StrTem = i.toString();
                    k = 9 + 6 * i;
                    document.getElementById("textcurrent" + StrTem).innerHTML = "Current : " + strResponse.substr(k, 4) + " mA";
                    SwitchImgOnOff("switchImage" + StrTem, strResponse.substr(k + 4, 1));
                    RelayState[i] = strResponse.substr(k + 4, 1);
                    SwitchImgDeviceState("devicestateimg" + StrTem, "textstatedevice" + StrTem, strResponse.substr(k + 5, 1));
                }
                document.getElementById("TimeOnline").innerHTML = strResponse.substr(33, 2) + ":" + strResponse.substr(35, 2) + ":" + strResponse.substr(37, 2) + "   " + StrDay[parseInt(strResponse.substr(39, 1)) - 1] + " " + strResponse.substr(40, 2) + "-" + strResponse.substr(42, 2) + "-" + strResponse.substr(44, 4);


            } else if (strResponse.substr(0, 6) == "<!--#o") {
                //alert(strResponse);
                var tem = strResponse.substr(9, 1);
                if (tem == "1") {
                    if (strResponse.substr(11, 1) == "1") {
                        AddOption(strResponse.substr(12, 5), "selectoption" + strResponse.substr(10, 1) + "on");
                    } else if (strResponse.substr(11, 1) == "0") {
                        AddOption(strResponse.substr(12, 5), "selectoption" + strResponse.substr(10, 1) + "off");
                    }


                    Mymsg("Thêm thành công");
                } else if (tem == "0") {
                    if (strResponse.substr(11, 1) == "1") // lelete on
                    {
                        RemoveOption(strResponse.substr(12, 5), "selectoption" + strResponse.substr(10, 1) + "on");
                    } else if (strResponse.substr(11, 1) == "0") //deleteoff
                    {
                        RemoveOption(strResponse.substr(12, 5), "selectoption" + strResponse.substr(10, 1) + "off");
                    }
                    Mymsg("Xóa thành công");
                } else if (tem == "8") {
                    if (strResponse.substr(11, 1) == "1") // lelete on
                    {
                        RemoveOption("all", "selectoption" + strResponse.substr(10, 1) + "on");
                    } else if (strResponse.substr(11, 1) == "0") //deleteoff
                    {
                        RemoveOption("all", "selectoption" + strResponse.substr(10, 1) + "off");
                    }
                    Mymsg("Đã xóa hết");
                } else if (tem == "2" || tem == "3" || tem == "4" || tem == "5" || tem == "6" || tem == "7") {
                    Mymsg(StrAlarmResuilt[parseInt(tem) - 2]);
                }

            }
        }
    }
}