#include "coapUDP.h"
#include "Arduino.h"

bool coapUDP::wifi_restart(){
	return _esp->restart();
}

bool coapUDP::wifi_setmodeSAP(){
    return _esp->setOprToStationSoftAP();
}

bool coapUDP::wifi_connect(String SSID,String pw){
	return _esp->joinAP(SSID,pw);
}

bool coapUDP::wifi_disconnect(){
	return _esp->leaveAP();
}

bool coapUDP::wifi_setupAP(String ID, String pw, int chl, int ecn){
	return _esp->setSoftAPParam(ID,pw,chl,ecn);
}

String coapUDP::wifi_getjoinedIP(){
	return _esp->getJoinedDeviceIP();
}

bool coapUDP::enable_show_remote(){
	return _esp->enableShowRemote();
}

bool coapUDP::disable_show_remote(){
	return _esp->disableShowRemote();
} 

bool coapUDP::start_UDPServer(int port){	
	 _esp->startTCPServer(port);
	 if(_esp->enableMUX()!=0){
	    return 	_esp->registerUDP(0,"0.0.0.0",port);   
        }
     else return false;
}

String coapUDP::remote_ip(uint8_t *buffer,uint32_t timeout){
	String remote_ip;
    remote_ip = _esp->getRemoteIP(buffer,timeout,0);
    return remote_ip;
}

int coapUDP::remote_port(uint8_t *buffer,uint32_t timeout){
	int remote_port;
    remote_port = _esp->getRemotePort(buffer,timeout,0);
    return remote_port;
}

bool coapUDP::send_UDP(String ip, uint32_t port,uint8_t *buffer,uint8_t length){
    if(_esp->registerUDP(0,ip,port)!=0)
    	if(_esp->send(0,buffer,length)!=0)
    		return _esp->unregisterUDP(0);
    	else return false;
    else return false;
}

uint32_t coapUDP::received_packetlen(uint8_t *buffer, uint32_t buffer_size, uint32_t timeout){
	return _esp->recv(buffer,buffer_size,timeout);
}