#include "coapUDP.h"
#include "IPAddress.h"
#include "Arduino.h"

ESP8266 _esp;

coapUDP::wifi_restart(){
	return _esp.restart();
}

coapUDP::wifi_setmode(uint8_t mode){
	switch (mode){
		case 1: return _esp.setOprToStation(void);
		case 2: return _esp.setOprToSoftAP(void);
		case 3: return _esp.setOprToStationSoftAP(void);
		default: return false;
	}
}

coapUDP::wifi_connect(String SSID,String pw){
	return _esp.joinAP(SSID,pw);
}

coapUDP::wifi_disconnect(){
	return _esp.leaveAP();
}

coapUDP::enMUX(){
	return _esp.enableMUX();
}

coapUDP::disMUX(){
	return _esp.disableMUX();
}

coapUDP::enable_show_remote(){
	return _esp.enableShowRemote();
}

coapUDP::disable_show_remote(){
	return _esp.disableShoeRemote();
} 

coapUDP::startUDPserver(int port){
	if(_esp.enableMUX())
	return 	_esp.registerUDP(0,"0.0.0.0",0,80,2);   
    else return false;
}

coapUDP::sendUDP(String ip, uint32_t port,uint8_t *buffer,uint8_t length){
    if(_esp.registerUDP(0,ip,port,80,2))
    	if(_esp.send(0,buffer,length))
    		return unregisterUDP(0);
    	else return false;
    else return false;
}