#ifndef _COAP_UDP_H_
#define _COAP_UDP_H_

#include "ESP8266.h"

class coapUDP {
     public:
     	coapUDP::coapUDP(); 
     	bool wifi_restart();
     	bool wifi_setmode(uint8_t mode);
        bool wifi_connect(String SSID,String pw);
        bool wifi_disconnect();
        bool wifi_enMUX();
        bool wifi_disMUX();
        bool start_UDPserver(int port);
        bool enable_show_remote();
        bool disable_show_remote();
        String remote_ip(uint8_t *buffer, uint32_t timeout);
        int remote_port(uint8_t *buffer, uint32_t timeout);
     	bool send_UDP(String ip, uint32_t port,uint8_t *buffer,uint8_t length);

};


#endif
