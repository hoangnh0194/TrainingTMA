#ifndef _COAP_UDP_H_
#define _COAP_UDP_H_

#include "ESP8266.h"

class coapUDP
{

     public:
        ESP8266* _esp;

     	coapUDP(ESP8266* esp){_esp=esp; }
     	bool wifi_restart();
     	bool wifi_setmodeSAP();
        bool wifi_connect(String SSID,String pw);
        bool wifi_disconnect();
        bool wifi_setupAP(String ID,String pw,int chl, int ecn);
        String wifi_getjoinedIP();
        bool start_UDPServer(int port);
        bool enable_show_remote();
        bool disable_show_remote();
        String remote_ip(uint8_t *buffer, uint32_t timeout);
        int remote_port(uint8_t *buffer, uint32_t timeout);
     	bool send_UDP(String ip, uint32_t port,uint8_t *buffer,uint8_t length);
        uint32_t received_packetlen(uint8_t *buffer, uint32_t buffer_size, uint32_t timeout);

};


#endif
