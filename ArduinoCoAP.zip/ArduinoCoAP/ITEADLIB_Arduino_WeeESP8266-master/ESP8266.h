/**
 * @file ESP8266.h
 * @brief The definition of class ESP8266. 
 * @author Wu Pengfei<pengfei.wu@itead.cc> 
 * @date 2015.02
 * 
 * @par Copyright:
 * Copyright (c) 2015 ITEAD Intelligent Systems Co., Ltd. \n\n
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License as
 * published by the Free Software Foundation; either version 2 of
 * the License, or (at your option) any later version. \n\n
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */
#ifndef __ESP8266_H__
#define __ESP8266_H__

#include "Arduino.h"


#define ESP8266_USE_SOFTWARE_SERIAL


#ifdef ESP8266_USE_SOFTWARE_SERIAL
#include "SoftwareSerial.h"
#endif


class ESP8266 {
 public:

#ifdef ESP8266_USE_SOFTWARE_SERIAL

    ESP8266(SoftwareSerial &uart, uint32_t baud = 115200);
#else /* HardwareSerial */

    ESP8266(HardwareSerial &uart, uint32_t baud = 9600);
#endif
    
 
    bool kick(void);

    bool restart(void);
    
    String getVersion(void);
    
    bool setOprToStation(void);
    
    bool setOprToSoftAP(void);
    
    bool setOprToStationSoftAP(void);
    
    String getAPList(void);
    
    bool joinAP(String ssid, String pwd);
    
    bool enableClientDHCP(uint8_t mode, boolean enabled);

    bool leaveAP(void);
    
    bool setSoftAPParam(String ssid, String pwd, uint8_t chl = 7, uint8_t ecn = 4);

    String getJoinedDeviceIP(void);
    
    String getIPStatus(void);
    
    String getLocalIP(void);

    bool enableMUX(void);

    bool disableMUX(void);
    
    bool createTCP(String addr, uint32_t port);
    
    bool releaseTCP(void);
    
    bool registerUDP(String addr, uint32_t port);

    bool unregisterUDP(void);

    bool createTCP(uint8_t mux_id, String addr, uint32_t port);

    bool releaseTCP(uint8_t mux_id);
    
    bool registerUDP(uint8_t mux_id, String addr, uint32_t port);

    bool unregisterUDP(uint8_t mux_id);

    bool setServerTimeout(uint32_t timeout = 180);

    bool startServer(uint32_t port);

    bool stopServer(void);

    bool send(const uint8_t *buffer, uint32_t len);

    bool send(uint8_t mux_id, const uint8_t *buffer, uint32_t len);

    uint32_t recv(uint8_t *buffer, uint32_t buffer_size, uint32_t timeout = 1000);
 
    uint32_t recv(uint8_t mux_id, uint8_t *buffer, uint32_t buffer_size, uint32_t timeout = 1000);
     
    uint32_t recv(uint8_t *coming_mux_id, uint8_t *buffer, uint32_t buffer_size, uint32_t timeout = 1000);
    
    int available();
 private:

    void rx_empty(void);
 
    String recvString(String target, uint32_t timeout = 1000);

    String recvString(String target1, String target2, uint32_t timeout = 1000);
 
    String recvString(String target1, String target2, String target3, uint32_t timeout = 1000);

    bool recvFind(String target, uint32_t timeout = 1000);

    bool recvFindAndFilter(String target, String begin, String end, String &data, uint32_t timeout = 1000);
 
    uint32_t recvPkg(uint8_t *buffer, uint32_t buffer_size, uint32_t *data_len, uint32_t timeout, uint8_t *coming_mux_id);
    
    
    bool eAT(void);
    bool eATRST(void);
    bool eATGMR(String &version);
    
    bool qATCWMODE(uint8_t *mode);
    bool sATCWMODE(uint8_t mode);
    bool sATCWJAP(String ssid, String pwd);
    bool sATCWDHCP(uint8_t mode, boolean enabled);
    bool eATCWLAP(String &list);
    bool eATCWQAP(void);
    bool sATCWSAP(String ssid, String pwd, uint8_t chl, uint8_t ecn);
    bool eATCWLIF(String &list);
    
    bool eATCIPSTATUS(String &list);
    bool sATCIPSTARTSingle(String type, String addr, uint32_t port);
    bool sATCIPSTARTMultiple(uint8_t mux_id, String type, String addr, uint32_t port);
    bool sATCIPSENDSingle(const uint8_t *buffer, uint32_t len);
    bool sATCIPSENDMultiple(uint8_t mux_id, const uint8_t *buffer, uint32_t len);
    bool sATCIPCLOSEMulitple(uint8_t mux_id);
    bool eATCIPCLOSESingle(void);
    bool eATCIFSR(String &list);
    bool sATCIPMUX(uint8_t mode);
    bool sATCIPSERVER(uint8_t mode, uint32_t port = 333);
    bool sATCIPSTO(uint32_t timeout);
    
    
#ifdef ESP8266_USE_SOFTWARE_SERIAL
    SoftwareSerial *m_puart; /* The UART to communicate with ESP8266 */
#else
    HardwareSerial *m_puart; /* The UART to communicate with ESP8266 */
#endif
};

#endif /* #ifndef __ESP8266_H__ */

