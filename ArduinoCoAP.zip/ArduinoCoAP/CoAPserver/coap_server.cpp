#include "coap_server.h"


coapUri uri;
IPAddress ipro;
resource_dis resource[MAX_CALLBACK];
coapPacket *request=new coapPacket();
coapPacket *response=new coapPacket();
coapObserver observer[MAX_OBSERVER];
