#include "coap_server.h"

#include "Arduino.h"

#define LOGGING

Coap::Coap(ESP8266& wifi) {
    this->_wifi = &wifi;
}

bool Coap::start() {
    this->start(COAP_DEFAULT_PORT);
    return true;
}

bool Coap::start(int port) {
    if(_wifi->enableMUX()==1)
        if(_wifi->startServer(port)==1)
            return _wifi->registerUDP(0,"0.0.0.0",port);
        else return false;
    else return false;
}

uint16_t Coap::sendPacket(CoapPacket &packet, uint8_t client_id) {
    uint8_t buffer[BUF_MAX_SIZE];
    uint8_t *p = buffer;
    uint16_t running_delta = 0;
    uint16_t packetSize = 0;

    // make coap packet base header
    *p = 0x01 << 6;//version =1
    *p |= (packet.type & 0x03) << 4;
    *p++ |= (packet.tokenlen & 0x0F);
    *p++ = packet.code;
    *p++ = (packet.messageid >> 8);
    *p++ = (packet.messageid & 0xFF);
    p = buffer + COAP_HEADER_SIZE;
    packetSize += 4;

    // make token
    if (packet.token != NULL && packet.tokenlen <= 0x0F) {
        memcpy(p, packet.token, packet.tokenlen);
        p += packet.tokenlen;
        packetSize += packet.tokenlen;
    }

    // make option header
    for (int i = 0; i < packet.optionnum; i++)  {
        uint32_t optdelta;
        uint8_t len, delta;

        if (packetSize + 5 + packet.options[i].length >= BUF_MAX_SIZE) {
            return 0;
        }
        optdelta = packet.options[i].number - running_delta;
        COAP_OPTION_DELTA(optdelta, &delta);
        COAP_OPTION_DELTA((uint32_t)packet.options[i].length, &len);

        *p++ = (0xFF & (delta << 4 | len));
        if (delta == 13) {
            *p++ = (optdelta - 13);
            packetSize++;
        } else if (delta == 14) {
            *p++ = ((optdelta - 269) >> 8);
            *p++ = (0xFF & (optdelta - 269));
            packetSize+=2;
        } if (len == 13) {
            *p++ = (packet.options[i].length - 13);
            packetSize++;
        } else if (len == 14) {
            *p++ = (packet.options[i].length >> 8);
            *p++ = (0xFF & (packet.options[i].length - 269));
            packetSize+=2;
        }

        memcpy(p, packet.options[i].buffer, packet.options[i].length);
        p += packet.options[i].length;
        packetSize += packet.options[i].length + 1;
        running_delta = packet.options[i].number;
    }

    // make payload
    if (packet.payloadlen > 0) {
        if ((packetSize + 1 + packet.payloadlen) >= BUF_MAX_SIZE) {
            return 0;
        }
        *p++ = 0xFF;
        memcpy(p, packet.payload, packet.payloadlen);
        packetSize += 1 + packet.payloadlen;
    }

    _wifi->send(client_id, p, packetSize);

    return packet.messageid;
}

int Coap::parseOption(CoapOption *option, uint16_t *running_delta, uint8_t **buf, size_t buflen) {
    uint8_t *p = *buf;
    uint8_t headlen = 1;
    uint16_t len, delta;

    if (buflen < headlen) return -1;

    delta = (p[0] & 0xF0) >> 4;
    len = p[0] & 0x0F;

    if (delta == 13) {
        headlen++;
        if (buflen < headlen) return -1;
        delta = p[1] + 13;
        p++;
    } else if (delta == 14) {
        headlen += 2;
        if (buflen < headlen) return -1;
        delta = ((p[1] << 8) | p[2]) + 269;
        p+=2;
    } else if (delta == 15) return -1;

    if (len == 13) {
        headlen++;
        if (buflen < headlen) return -1;
        len = p[1] + 13;
        p++;
    } else if (len == 14) {
        headlen += 2;
        if (buflen < headlen) return -1;
        len = ((p[1] << 8) | p[2]) + 269;
        p+=2;
    } else if (len == 15)
        return -1;

    if ((p + 1 + len) > (*buf + buflen))  return -1;
    option->number = delta + *running_delta;
    option->buffer = p+1;
    option->length = len;
    *buf = p + 1 + len;
    *running_delta += delta;

    return 0;
}

bool Coap::handle_request() {

    uint8_t clientID;
    uint8_t buffer[BUF_MAX_SIZE];
    int32_t packetlen = _wifi->recv(clientID , buffer, BUF_MAX_SIZE, 5000);/////////

    if(packetlen > 0) {
	Serial.println("Now we are in the COAP loop");
        //packetlen = _wifi->read(buffer, packetlen >= BUF_MAX_SIZE ? BUF_MAX_SIZE : packetlen);

        CoapPacket request;/////coappacket instance for request mes

        // parse coap packet header
        if (packetlen < COAP_HEADER_SIZE || (((buffer[0] & 0xC0) >> 6) != 1)) {
            packetlen = _wifi->recv(clientID,buffer,BUF_MAX_SIZE,5000);//////////
        }
        request.version=(buffer[0] & 0xC0)>>6;
        request.type = (buffer[0] & 0x30) >> 4;
        request.tokenlen = buffer[0] & 0x0F;
        request.code = buffer[1];
        request.messageid = 0xFF00 & (buffer[2] << 8);
        request.messageid |= 0x00FF & buffer[3];

        if (request.tokenlen == 0)  request.token = NULL;
        else if (request.tokenlen <= 8) {       
            request.token=new uint8_t(request.tokenlen);
            memset(request.token,0,request.tokenlen);
            for(int i=0;i<request.tokenlen ;i++)
            {
                request.token[i]=buffer[4+i];
            }

        }
        else {
            packetlen = _wifi->recv(clientID,buffer,BUF_MAX_SIZE,5000);///////
        }

        // parse packet options/payload
        if (COAP_HEADER_SIZE + request.tokenlen < packetlen) {
            int optionIndex = 0;
            uint16_t delta = 0;
            uint8_t *end = buffer + packetlen;
            uint8_t *p = buffer + COAP_HEADER_SIZE + request.tokenlen;
            while(optionIndex < MAX_OPTION_NUM && *p != 0xFF && p < end) {
                request.options[optionIndex];
                if (0 != parseOption(&request.options[optionIndex], &delta, &p, end-p))
                    return false;
                optionIndex++;
            }
            request.optionnum = optionIndex;

            if (p+1 < end && *p == 0xFF) {
                request.payload = p+1;
                request.payloadlen = end-(p+1);
            } else {
                request.payload = NULL;
                request.payloadlen= 0;
            }
        }

        CoapPacket response;/////coappacket instance for reponse mes

        // String url = "";
        // for (int i = 0; i < request.optionnum; i++) {
        //     if (request.options[i].number == COAP_URI_PATH && request.options[i].length > 0) {
        //         char urlname[request.options[i].length + 1];
        //         memcpy(urlname, request.options[i].buffer, request.options[i].length);
        //         urlname[request.options[i].length] = NULL;
        //         if(url.length() > 0)
        //             url += "/";
        //         url += urlname;
        //     }
        // }
        // if(url==String(".well-known/core")){
        //     resourceDiscovery(response,Udp.remoteIP(),Udp.remotePort(),resource);
        // }
        if(request.type== COAP_CON){
            response.version=request.version;
            response.type=COAP_ACK;
            response.tokenlen=request.tokenlen;
            response.messageid=request.messageid;
            response.token=request.token;
        }
        else if (request.type==COAP_NONCON){
            response.version=request.version;
            response.type=COAP_NONCON;
            response.tokenlen=request.tokenlen;
            response.messageid=request.messageid;
            response.token=request.token;
        }

        if(request.code==COAP_GET){
            response.code = COAP_CONTENT;
            String str="GET OK";
            char *payl=str.c_str();
            response.payload=(uint8_t *)payl;
            response.payloadlen = strlen(payl); 
            response.optionnum = 0; 
            sendPacket(response, clientID);     
            // if(!uri.find(url)){
            //     response.payload=NULL;
            //     response.payloadlen=0;
            //     response.code=COAP_NOT_FOUND;

            //     response.optionnum=0;

            //     char optionBuffer[2];
            //     optionBuffer[0] = ((uint16_t)COAP_TEXT_PLAIN  & 0xFF00) >> 8;
            //     optionBuffer[1] = ((uint16_t)COAP_TEXT_PLAIN  & 0x00FF) ;
            //     response.options[response.optionnum].buffer = (uint8_t *)optionBuffer;
            //     response.options[response.optionnum].length = 2;
            //     response.options[response.optionnum].number = COAP_CONTENT_FORMAT;
            //     response.optionnum++;

            //     sendPacket(response,clientID);   

            // }else{
                // uri.find()(request,clientID);
             }

        // }else if(request.code==COAP_PUT||request.code==COAP_POST){

        //         if(!uri.find(url)){

        //             response.payload=NULL;
        //             response.payloadlen=0;
        //             response.code=COAP_NOT_FOUND;


        //             response.optionnum=0;

        //             char optionBuffer[2];
        //             optionBuffer[0] = ((uint16_t)COAP_TEXT_PLAIN  & 0xFF00) >> 8;
        //             optionBuffer[1] = ((uint16_t)COAP_TEXT_PLAIN  & 0x00FF) ;
        //             response.options[response.optionnum].buffer = (uint8_t *)optionBuffer;
        //             response.options[response.optionnum].length = 2;
        //             response.options[response.optionnum].number = COAP_CONTENT_FORMAT;
        //             response.optionnum++;

        //             sendPacket(response,clientID);   

        //         }else{
        //             uri.find(url)(request,clientID);
        //         }
        // }else if(request.code==COAP_DELETE){

        //         if(!uri.find(url)){
        //             response.payload=NULL;
        //             response.payloadlen=0;
        //             response.code=COAP_NOT_FOUND;

        //             response.optionnum=0;

        //             char optionBuffer[2];
        //             optionBuffer[0] = ((uint16_t)COAP_TEXT_PLAIN  & 0xFF00) >> 8;
        //             optionBuffer[1] = ((uint16_t)COAP_TEXT_PLAIN  & 0x00FF) ;
        //             response.options[response.optionnum].buffer = (uint8_t *)optionBuffer;
        //             response.options[response.optionnum].length = 2;
        //             response.options[response.optionnum].number = COAP_CONTENT_FORMAT;
        //             response.optionnum++;

        //             sendPacket(response,clientID);   

        //         }else{}//delete nothing
        //}
    }
}

uint16_t Coap::sendResponse(uint8_t client_id, uint16_t messageid) {
    this->sendResponse(client_id, messageid, NULL, 0, COAP_CONTENT, COAP_TEXT_PLAIN, NULL, 0);
}

uint16_t Coap::sendResponse(uint8_t client_id, uint16_t messageid, char *payload) {
    this->sendResponse(client_id, messageid, payload, strlen(payload), COAP_CONTENT, COAP_TEXT_PLAIN, NULL, 0);
}

uint16_t Coap::sendResponse(uint8_t client_id, uint16_t messageid, char *payload, int payloadlen) {
    this->sendResponse(client_id, messageid, payload, payloadlen, COAP_CONTENT, COAP_TEXT_PLAIN, NULL, 0);
}


uint16_t Coap::sendResponse(uint8_t client_id, uint16_t messageid, char *payload, int payloadlen,
                COAP_RESPONSE_CODE code, COAP_CONTENT_TYPE type, uint8_t *token, int tokenlen) {
    // make packet
    CoapPacket packet;

    packet.type = COAP_ACK;
    packet.code = code;
    packet.token = token;
    packet.tokenlen = tokenlen;
    packet.payload = (uint8_t *)payload;
    packet.payloadlen = payloadlen;
    packet.optionnum = 0;
    packet.messageid = messageid;

    // if more options?
    char optionBuffer[2];
    optionBuffer[0] = ((uint16_t)type & 0xFF00) >> 8;
    optionBuffer[1] = ((uint16_t)type & 0x00FF) ;
    packet.options[packet.optionnum].buffer = (uint8_t *)optionBuffer;
    packet.options[packet.optionnum].length = 2;
    packet.options[packet.optionnum].number = COAP_CONTENT_FORMAT;
    packet.optionnum++;

    return this->sendPacket(packet,client_id);
}
