#include<iostream>
#include<string>
#include<stdlib.h>
using namespace std;

template<class T> class Element{
public:
   T data;
   Element *next;
public:
   Element(T const &info){next = NULL;data = info;}
   ~Element();
};
template<class T> class Stack_or_Queue{
protected:Element<T> *pfirst,*plast;
public:
      Stack_or_Queue(){pfirst = NULL;};
      ~Stack_or_Queue();
      int CountItem();
      void Pop();
      bool Is_emty();
};
template <class T> class Stack: public Stack_or_Queue
{
public:
      void push(T const&);


};
template <class T> class Queue: public Stack_or_Queue
{
public:
     void Insert(T const&);

};
////////

bool Stack_or_Queue<T>::Is_empty()
{
     if(pfirst == NULL) return true;
     else return false;
}
int Stack_or_Queue<T>::CountItem()
{
     int t =0;
     Element *i;
     while(i!=NULL)
     {
         t=t+1;
         i=i->next;
     }
     return t;
}
void Stack_or_Queue<T>::Pop()
{
     if(CountItem()==0)
     {
         cout<<"List is empty!";
         return 0;
     }
     Element *del,*temp;
     else if(CountItem()==1)
     {
         del = pfirst;
         pfirst =plast = NULL;
         cout<<"Deleted:"<<del->data<<endl;
     }
     else
     {
         temp = pfirst;
         pfirst = pfirst->next;
         del = temp;
         temp = NULL;
         cout<<"Deleted:"<<temp->data<<endl;
     }
}
void Stack<T>::push(T const &key)
{
    Element *ele = new Element::Element(T key);
    if(!ele) {cout<<"Out of memory!"; exit(1);}
    if(pfirst == NULL && plast==NULL)
    {
        ele->next = NULL;
        pfrist = plast = ele;
        cout<<"Pushed:"<<ele->data<<endl;
    }
    else
    {
        ele->next = pfirst;
        pfirst = ele;
        cout<<"Pushed:"<<ele->data<<endl;
    }

}
void Queue<T>::Insert(T const &key)
{
    Element *ele = new Element::Element(T key);
    if(!ele) {cout<<"Out of memory!"; exit(1);}
    if(pfirst == NULL && plast==NULL)
    {
        ele->next = NULL;
        pfrist = plast = ele;
        cout<<"Pushed:"<<ele->data<<endl;
    }
    else
    {

    }

}
////////
int main()
{
return 0;
}
