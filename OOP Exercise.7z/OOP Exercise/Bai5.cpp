#include<iostream>
#include<string>
#include<stdlib.h>
using namespace std;

template <class T> class Element
{
public:
   T data;
   Element *next;
public:
   Element(T info)
   {
       next = NULL;data = info;
   }
};
template <class T> class Stack_or_Queue
{
public:
      Element<T> *pfirst,*plast;
public:
      Stack_or_Queue<T>()
      {
         pfirst = plast = NULL;
      }
      int CountItem();
      void Push(T);
      void Insert(T);
      void Pop();
      bool Is_emty(){ if(!pfirst)return true; return false; }
      void show_item();
};
template <class T> class Stack : public Stack_or_Queue<T>
{
public:
      void Push(T);
};
template <class T> class Queue : public Stack_or_Queue<T>
{
public:
     void Insert(T);
};
//////////////////////////////

template <class T> int Stack_or_Queue<T>::CountItem()
{
     int t =0;
     Element<T> *i;
     i=pfirst;
     while(i!=NULL)
     {
         t=t+1;
         i=i->next;
     }
     return t;
}

template <class T> void Stack_or_Queue<T>::Push(T key)
{
    Element<T> *ele = new Element<T>(key);
    //if(!ele) {cout<<"Out of memory!"; exit(1);}
    if(Is_emty()==true)
    {
        ele->next = NULL;
        pfirst = plast = ele;
        cout<<"Pushed"<<endl;
    }
    else
    {
        ele->next = pfirst;
        pfirst = ele;
        cout<<"Pushed"<<endl;
    }

}

template <class T> void Stack_or_Queue<T>::Insert(T key)
{
    Element<T> *ele = new Element<T>(key);
    //if(!ele) {cout<<"Out of memory!"; exit(1);}
    if(Is_emty()==true)
    {
        ele->next = NULL;
        pfirst = plast = ele;
        cout<<"Inserted"<<endl;
    }
    else
    {   ele->next = NULL;
        plast->next = ele;
        ele = plast;
        cout<<"Inserted"<<endl;
    }

}
template <class T> void Stack_or_Queue<T>::Pop()
{
     if(CountItem()==0)
     {
         cout<<"List is empty!\n";
         return;
     }
     Element<T> *del;
     if(CountItem()==1)
     {
         del = pfirst;
         pfirst =plast = NULL;
         cout<<"Deleted:"<<del->data<<endl;
         delete del;
     }
     else
     {
         del = pfirst;
         pfirst = pfirst->next;
         cout<<"Deleted:"<<del->data<<endl;
         delete del;
     }
}
template<class T> void Stack_or_Queue<T>::show_item()
{
     Element<T> *ele;
     ele = pfirst;
     if(pfirst!=NULL){
         while(ele){
         cout<<ele->data<<endl;
         ele=ele->next;
        }
    }
     else cout<<"List empty!\n";
}
///////////////////////////////////////////
int main()
{
     char n;
     int num;
     string value;
     Stack_or_Queue<string> *SaQ = new Stack_or_Queue<string>();

  while(1){
    cout<< "Stacks and Queues as linked list menu:\n"
     <<"1.Push an item into stack of list\n"
     <<"2.Pop an item from stack of list\n"
     <<"3.Insert an item into the end of list\n"
     <<"4.Show number of item of list\n"
     <<"5.Show all list's items\n"
     <<"6.Exit!\n"
     <<"Enter your choise!\n";

     cin>>n;
   switch(n)
     {
     case '1': cout<<"Enter pushed data: "; cin>>value;
               SaQ->Push(value);
               break;
     case '2': cout<<"Pop an item.....\n"; SaQ->Pop();
               break;
     case '3': cout<<"Enter inserted data : ";cin >>value;
               SaQ->Insert(value);
               break;
     case '4': num = SaQ->CountItem();
               if(num==0) cout<<"List empty!";
               cout<<"Number of item is "<<num<<endl;
               break;
     case '5': cout<<"All items of list:\n";
               SaQ->show_item();
               break;
     case '6': exit(1);
     default : cout<<"Invalid key!\n";
     }
   }
     return 0;
}
