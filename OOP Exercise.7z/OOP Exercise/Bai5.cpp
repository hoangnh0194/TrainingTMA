#include<iostream>
#include<string>
#include<stdlib.h>
using namespace std;

struct Node{
int info;
Node *prev,*next;
};
struct List{
Node *head,*tail;
};
////tao ds rong
void createlist(List &list)
{
   list.head = list.last = NULL;
}
////dua du lieu vao node
Node* createnode(int data)
{
   Node* node = new node;
   if(node)
   {
   node->info = data;
   node->prev = node->next = NULL;
   }
}
////them node vao ds
void addhead(List *list,Node* node)
{
    if(!list.head)
    list.head = list.tail =node;
    else
    {
    node->next = list.head;
    list.head->prev = node;
    list.head = node;
    }
}
void addtail(List &list,Node* node)
{
    if(!list.tail)
    list.head=list.tail=node;
    else
    {
    node->prev = list.tail;
    list.tail->next = node;
    list.tail=node;
    }
}

int main()
{
return 0;
}
