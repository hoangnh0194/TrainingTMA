#include<iostream>
#include<string>
#include<stdlib.h>
using namespace std;

template<class T> class Element{
public:
   T data;
   Element *next;
public:
   Element(const T info){next = NULL;data = info;}
   ~Element();
};
template<class T> class Stack_or_Queue{
protected:Element<T> *pfirst;
public:
      Stack_or_Queue(){pfirst = NULL;};
      ~Stack_or_Queue();
      T Pop();
      bool Is_emty();
};
template <class T> class Stack: public Stack_or_Queue
{
public:
      void push(T);


};
template <class T> class Queue: public Stack_or_Queue
{
public:
     void insert(T);

};
////////
int main()
{
return 0;
}
