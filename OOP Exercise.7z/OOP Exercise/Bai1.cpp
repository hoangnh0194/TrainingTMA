#include<iostream>
#include<string>
#include<math.h>
using namespace std;
class shape{
protected: 
    int dimension;
public: 
    void set_dimension(int a){dimension = a;}
    virtual float area(){return 0;}
};
class square: public shape{
public: 
   float area()
   {
    return dimension*dimension;
   }
};
class circle: public shape{
public: 
    float area()
   {
    return dimension*dimension*3.14/4;//dimension is parameter
   }
};
class equtriangle: public shape{
public: float area()
   { 
    return dimension*dimension*sqrt(2)/2;//dimension is egde length
   }
};
int main()
{
    square sqr;
    circle cir;
    equtriangle eta;
    shape *sh = &sqr;
    sh->set_dimension(5);
    cout<<sh->area()<<"\n"; 
    shape *sh1 = &cir;
    sh1->set_dimension(5);
    cout<<sh1->area()<<"\n"; 
    shape *sh2 = &eta;
    sh2->set_dimension(5);
    cout<<sh2->area()<<"\n"; 

    return 0;
}
