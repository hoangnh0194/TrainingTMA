#include<iostream>
#include <string>
using namespace std;
class pet{
protected:
     int age;
     string name;
     float weight;
public:
     void get_name(string str){name=str;}
     void get_age(int a) {age = a;}
     void show();
     virtual void eat()=0;
     virtual void sleep()=0;
     virtual void run(){cout<<"Who can run?\n";}
     virtual void swim(){cout<<"who can swim?\n";}
};

class dog:public pet{
public: 
       void run(){ cout<<name<<" can run!\n";}
       void eat(){ cout<<name<<" eat everything!\n";}
       void sleep(){ cout<<name<<" sleep everywhere!\n";}
};
class fish: public pet{
public: 
       void swim() {cout<<name<<" can swim\n";}
       void eat() {cout<<name<<" eat grass!\n";}
       void sleep() {cout<<name<<" dont sleep on its bed!\n";}
};
void pet::show()
{
      cout<<name<<" is "<<age<<endl;    
}
int main()
{     
      int a,a1;
      string str,str1;
      dog d1;
      fish f1;
      pet *p=&d1;
      pet *p1=&f1;
      cout<<"The dog's name is: ";
      cin>>str;
      cout<<"It's age is: ";
      cin>>a;
      cout<<"The fish's name is: ";
      cin>>str1; 
      cout<<"Its age is: ";
      cin>>a1;
      p->get_name(str);
      p->get_age(a);
      p1->get_name(str1);
      p1->get_age(a1);
      cout<<"You say: \n";
      p->show();p->eat();p->sleep();
      p1->show();p1->eat();p1->sleep();
      return 0;
}
