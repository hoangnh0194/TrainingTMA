#include<iostream>
#include <string>
using namespace std;
class pet{
int age;
string name;
float weight;
public: 
void get_name(){cout<<"Its name is: ";cin>>name;}
void get_age() {cout<<"It is:  ";cin>>age;}
virtual int eat()=0;
virtual int sleep()=0;
virtual void run(){cout<<"Who can run?\n";}
virtual void swim(){cout<<"who can swim?\n";}
};

class dog:public pet{
public: void run(){ cout<<"Dog can run!\n";}
       int eat(){ cout<<"Dog eat everything!\n";}
       int sleep(){cout<<"Dog sleep everywhere!\n";}
};
class fish: public pet{
public: void swim() {cout<<"Fish can swim\n";}
      int eat(){"Fish eat grass!\n";}
       int sleep() {cout<<"Fish dont sleep on his bed!\n";}
};       
int main()
{
dog d1;
fish f1;
pet *p=&d1;
pet *p1=&f1;
p->get_name();
p->get_age();
p1->get_name();
p1->get_age();
cout<<"People says \n";
p->eat();
p1->sleep();
return 0;
}
