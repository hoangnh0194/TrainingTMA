#include<iostream>
#include<string>
using namespace std;

struct Node
{
int data;
    Node *prev,*next;
};
class List
{
private:
      Node *pfirst,*plast;
public:
     void creatList(List &list){list.pfirst=list.plast=NULL;}
     Node* creatnode(int item);
     void addfirst(List &list,Node* node);
     void addlast(List &list,Node* node);
     void addbefore(List &list,Node* node,Node* before);
     void addafter(Node* node,Node* after);
     void deletefirst(List &list,Node* node);
     void deletelast(List &list,Node* node);
     void deleteafter(List &list,Node* node,Node* after);
     void deletebefore(List &list,Node* node,Node* before);
     void showall();
     void showitem(List list,int item);
     Node* findnode(int key);
};
//////
void List::showall()
{   Node* node;
    List list;
    for (Node *i = list.pfirst;i!=NULL;i=i->next)
    {
      cout <<node->data<<endl;
    }
}
//////
Node* List::findnode(int key)
{   List list;
    Node *i = list.pfirst;
    while (i &&i->data!= key)
    i=i->next;
    return i;
}
/////
Node* List::creatnode(int item)
{
  Node* node = new Node;
if(node)
{
  node->data = item;
  node->next = NULL;
}
return node;
}
///////
void List::addfirst(List &list,Node* node)
{
if(!list.pfirst)//ds=null
    list.pfirst=list.plast=node;
else
   {
     node->next = list.pfirst;
     list.pfirst = node;
   }
}
//////
void List::addlast(List &list,Node* node)
{
if(!list.pfirst)//ds=null
    list.pfirst=list.plast=node;
else
   {
     list.plast->next = node;
     list.plast = node;
    }
}
///////
void List::addafter(Node* node,Node* after)
{    List list;
if(after)
  {
    node->prev = after;
    node->next = after->next;
    after->next = node;
    if(list.plast != after)
      after->next->prev = node;
    if(list.plast == after) list.plast = after;
   }
else
    addfirst(list,node);
}
//////
void List::addbefore(List &list,Node* node,Node* before)
{
if(before)
  {
    node->next = before;
    node->prev = before->prev;
    if(list.pfirst != before)
      before->prev->next =node;
    if(list.pfirst == before) list.pfirst = before;
   }
else
    addlast(list,node);
}
///////con nua
///////
int main()
{
int n;
cout<<"Doubly Linked List operation menu:\n";
cout<<"1.Add a new item\n"
<<"2.Delete an item\n"
<<"3.Show number of item\n"
<<"4.Find min item\n"
<<"5.Fine max item\n"
<<"6.Print item\n"
<<"7.Print all items\n"
<<"8.Exit\n";
re_enter:
cout<<"Enter your choise! ";
cin>>n;
switch(n)
{
case 1:
      {
      int i,j;
      cout<<"Add new item into list,enter its value: "; cin>>i;
      cout<<"Its location is after item:"; cin>>j;
      List list,list1,list2;
      Node* n = list.creatnode(i);
      Node* n1 = list.findnode(j);
      list.addafter(n,n1);
      list2.showall();
      break;
      }
case 2:cout<<"you want to delete my item? No way!";break;
case 3:break;
case 4:break;
case 5:break;
case 6:break;
case 7:break;
case 8:break;
default:
       cout<<"Not accepted choise,re- ";
       goto re_enter;
}
return 0;
}

