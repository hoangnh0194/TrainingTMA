#include<iostream>
#include<string>
using namespace std;

struct Node
{
    int info;
    Node *prev,*next;
};
struct List
{
   Node *head, *tail;
};
void creatlist(List &list)
{
   list.head=list.tail =NULL;
}
Node* CreateNode(int data)
{
   Node* node = new Node;
   if (node)
   {
      node->info = data;
      node->prev = node->next = NULL;
   }
}
void addhead(Node* node)
{  List list;
   if (!list.head)
      list.head = list.tail = node;
   else
   {
      node->next = list.head;
      list.head->prev = node;
      list.head = node;
   }
}
void addtail(Node* node)
{
   List list;
   if (!list.head)
   list.head = list.tail = node;
   else
   {
       node->prev = list.tail;
       list.tail->next = node;
       list.tail = node;
   }

}
Node* SearchNode( int key)
{  List list;
   Node *i = list.head;
   while (i && i->info != key)
      i = i->next;
   return i;
}

void ShowNext()
{  List list;
   for (Node *i = list.head;i==NULL; i = i->next)
   {
      cout<<i->info<<endl;
   }
}
void ShowPrev()
{  List list;
   for (Node*i = list.tail; i; i = i->prev)
   {
      cout<<i->info<<endl;
   }
}
int NumberofItem()
{   List list;
    int j=0;
    for (Node*i = list.head; i!=NULL; i = i->next)
    j++;
    return j;
}

///////
int main()
{    int i=0;
    addhead(CreateNode(1));
    addhead(CreateNode(2));
    addhead(CreateNode(2));
    addhead(CreateNode(4));
cout<<"Doubly Linked List operation menu:\n";
cout<<"1.Add a new item\n"
<<"2.Delete an item\n"
<<"3.Show number of item\n"
<<"4.Find min item\n"
<<"5.Fine max item\n"
<<"6.Print item\n"
<<"7.Print all items\n"
<<"8.Exit\n";
re_enter:
cout<<"Enter your choise! ";
cin>>i;
switch(i)
{
case 1:{int item;
      cout<<"Add elenent into list:"; cin>>item;
      addhead(CreateNode(item));
      ShowNext();
      break;
      }
case 2:cout<<"you want to delete my item? No way!";break;
case 3:{
      cout<<"Number of item is:" <<NumberofItem();
      break;
      }
case 4:break;
case 5:break;
case 6:break;
case 7:{
       List list;
       if(list.head==NULL) cout<<"List emty!";
       else
       ShowNext();
       break;}
case 8:break;
default:
       cout<<"Not accepted choise,re- ";
       goto re_enter;
}

return main();
}
