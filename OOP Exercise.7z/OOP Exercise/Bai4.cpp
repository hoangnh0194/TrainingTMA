#include<iostream>
#include<string>
#include<stdlib.h>
using namespace std;

class Node
{
  public:
    int data;
    Node *prev,*next;
  public:
    Node(const int &key) {prev = next =NULL; data = key;}
};
class DList
{
    Node *head, *tail;
  public: Node *temp;
  public:
    DList(){head = tail = NULL;}
    ~DList();
    void InsertNode(int,int);
    void DeleteNode(int);
    void ShowAll();
    int numberofitem();
    Node *FindMax();
    Node *FindMin();
    Node *FindItem(int);
};
//
void DList::InsertNode(int value,int pos)
{
    Node *node = new Node(value);
    bool Inserted = false;

    if(head == NULL && tail == NULL)//List emty
    {
        node ->prev = node->next = NULL;
        head = tail =node;
        Inserted = true;
    }
    else if(pos==1)//add head
    {
        node->next = head;
        node ->prev =NULL;
        head = node;
        Inserted=true;
    }
    else if(pos>1&&pos<=numberofitem())
    {
        Node *n1;
        n1 = head;
        for(int t = 1;t<pos;t++) { n1 = n1->next;}//move to insert point
        node -> next = n1;
        node->prev = n1->prev;
        n1->prev->next = node;
        n1->prev = node;
        Inserted = true;
    }
    else if(pos == numberofitem()+1)//Add tail
    {
        node ->next = NULL;
        tail->next = node;
        node->prev = tail;
        tail = node;
        Inserted = true;
    }
    else cout<<"cannot insert!\n";
    if(Inserted!=false)cout<<"Inserted\n";
}
int DList::numberofitem()
{
     Node *i;int t=0;
     i=head;
     while(i!= NULL)
     {
        t=t+1;
        i=i->next;
     }
     return t;
}
void DList::DeleteNode(int pos)
{
    int i;
    bool deleted = false;
    if(head != NULL)//list is not empty
    {
       Node *temp,*del;
       if(pos==1)
       {
         if(numberofitem()==1)
         {  
            //head = tail = NULL;
            delete head,tail;
            deleted = true;
         }
         else
         {
            del = head;
            head = head->next;
            head->prev = NULL;
            delete del;
            deleted = true;
         }
       }
       else if(pos>>1&&pos<=numberofitem())
       {
            del = head;
            for(i=1;i<pos;i++){del = del->next;temp = del ->prev;}
            if(del->next = NULL)//delete last node
            {
               tail = temp;
               temp->next = NULL;
               delete del;return;
            }
            else {
               temp->next = del->next;
               del->next->prev=temp;
               delete del;return;
                 }
            deleted = true;
       }
       else cout<<"Invalid Position!\n";
    }
    else cout<<"no item found!\n";
    if(deleted!= false) cout<<"deleted!\n";
 }
Node* DList::FindMin()
{
   Node *min,*tr;
   min =head;
   tr = head;
   if(head!= NULL)
   {
      while(tr!= NULL)
      {
          if(tr->data<min->data)
          min=tr;
          tr=tr->next;
      }
      return min;
   }
   else return NULL;

}
Node* DList::FindMax()
{
   Node *max,*tr;
   max= head;
   tr = head;
   if(head!=NULL)
   {
       while(tr!=NULL)
       {
           if(tr->data>max->data) max=tr;
           tr=tr->next;
       }
       return max;
   }
   else return NULL;
}
Node* DList::FindItem(int key)
{
   Node *tr;
   tr = head;
   if(head!= NULL)
   {
       while(tr!=NULL)
       {
          if(tr->data==key) break;
          else tr = tr->next;
       }
   }
   return tr;
}
void DList::ShowAll()
{
   Node *i;
   i=head;
   if(head!=NULL)
   {  int t = 1;
      while(i!=NULL){
      cout<<"<"<<t<<":"<<i->data<<">"<<endl;
      i=i->next;t++;
      }
   }
   else cout<< "there is no item!\n";
}


int main()
{   char n;
    int value,pos;
    DList *list = new DList();
while(1)
{
    cout<<"Doubly Linked List operation menu:\n"
        <<"1.Add a new item\n"
        <<"2.Delete an item\n"
        <<"3.Show number of item\n"
        <<"4.Find min item\n"
        <<"5.Fine max item\n"
        <<"6.Print item\n"
        <<"7.Print all items\n"
        <<"8.Exit\n";
    cout<<"Enter your choise! ";
    cin>>n;
switch(n)
{
case '1':{
      cout<<"Add new item!\n"<<"item 's Value:";
      cin>>value;
      cout<<"item 's position:";
      cin>>pos;
      list->InsertNode(value,pos);
      break;
      }
case '2':
      cout<<"delete item:\n"<<"item 's position:";
      cin>>pos; cout<<endl;
      list->DeleteNode(pos);
      break;
case '3':
      cout<<"Number of item is:"<<list->numberofitem()<<endl;
      break;
case '4':
      list->temp = list ->FindMin();
      if(list->temp!=NULL) cout<<"The min item:"<<list->temp->data<<endl;
      else cout<<"Not found\n";
      break;
case '5':
      list->temp = list ->FindMax();
      if(list->temp!=NULL) cout<<"The max item:"<<list->temp->data<<endl;
      else cout<<"Not found\n";
      break;
case '6':
      cout<<"Find item:";
      cin>>value;
      list->temp=list->FindMax();
      if(list->temp!=NULL) cout<<"Found "<<list->temp->data<<endl;
      else cout<<"not found!\n";
      break;
case '7':
       cout<<"All items:\n";
       list->ShowAll();
      break;
case '8': exit(1);
default: cout<<"Invalid key!";
}
}
return 0;

}
