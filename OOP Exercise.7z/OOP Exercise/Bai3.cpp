#include<iostream>
#include<string>
#include<math.h>
using namespace std;
class number{
protected: int value;
public:
       void get_value()
        { int a;
          cout<<"Input is:";cin>>a;value=a;}
};
class Hexnumber: public number{
public:
       void show_value()
        { cout<< "\nHexa value is:"<<hex<<value;}
};
class Octnumber: public number{
public:
       void show_value()
        { cout<< "\nOcta value is:"<<oct<<value;}
};
class Decnumber: public number{
public:
       void show_value()
        { cout<< "\nDeci value is:"<<dec<<value<<endl;}
};




int main()
{
Hexnumber hexn;
Octnumber octn;
Decnumber decn;
decn.get_value();
hexn.show_value();
octn.show_value();
decn.show_value();
return 0;
}
