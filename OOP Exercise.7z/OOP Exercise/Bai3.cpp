#include<iostream>
#include<string>
#include<math.h>
using namespace std;


class number{
protected: int value;
public:
       void get_value(int a){value=a;}
       virtual void show_value(){cout<<"Nonono";}
};
class Hexnumber: public number{
public:
       void show_value();
};
class Octnumber: public number{
public:
       void show_value();
};
class Decnumber: public number{
public:
       void show_value();
};
void Hexnumber::show_value()
{      char Hexa[6]={'A','B','C','D','E','F'};
       int temp[20],i=0,j=0;
       while(value>0)
       {
         temp[i]=value%16;
         value=value/16;
         i++;
       }
       cout<<"Hexa value is:";
       j=i;
       while(j>0)
       {
         if(temp[j-1]<10)
         cout<<temp[j-1];
         else
         cout<<Hexa[temp[j-1]-10];
         j--;
       }
       cout<<endl;
}
void Octnumber::show_value()
{      
       int temp[20],i=0,j=0;
       while(value>0)
       {
         temp[i]=value%8;
         value=value/8;
         i++;
       }
       cout<<"Octa value is:";
       j=i;
       while(j>0)
       {
         cout<<temp[j-1];
         j--;
       }
       cout<<endl;
       
}
void Decnumber::show_value()
{
      cout<< "Decima value is:"<<value<<endl;
}



int main()
{
    int a;
    number num;
    Hexnumber hexn;
    Octnumber octn;
    Decnumber decn;
    cout<<" Nhap so: ";
    cin>>a;
    number *n=&hexn;
    number *n1=&octn;
    number *n2=&decn;
    n->get_value(a);
    n->show_value();
    n1->get_value(a);
    n1->show_value();
    n2->get_value(a);
    n2->show_value();
    return 0;
}
