#include "liblwm2m.h"
#include "lwm2mclient.h"
#include <wiringPi.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <time.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>
#include <errno.h>
///////////////////////////////

#define PRV_SENSOR_TEMP        read_sensor("/sys/bus/w1/devices/28-000004d639f6/w1_slave")
#define PRV_LIGHT_STATE        LedState
#define PRV_REFERENCE_VALUE    Ref_Value

#define RES_O_SENSOR_TEMP     1
#define RES_O_LIGHT_STATE     2
#define RES_O_REFERENCE_VALUE 3

int LedState = 0;
int Ref_Value = 100;

typedef struct
{
    int64_t free_memory;
    int64_t error;
    int64_t time;
    int64_t state;
    int64_t reference;
    uint8_t battery_level;
} device_data_t;

//led control function

void led_control(int state)
{
    wiringPiSetupGpio();
    pinMode(17, OUTPUT);
    if (state == 0 )
       digitalWrite(17, LOW);
    else 
       digitalWrite(17, HIGH);
    return;
}

//char* addr = "/sys/bus/w1/devices/28-fffffffff/w1_slave", ffffffff is unique ID of sensor
float read_sensor(char* addr)
{
    float temp;
    int i, j;
    int fd;
    int ret;

    char buf[128];
    char tempBuf[5];

    fd = open(addr, O_RDONLY);

    if(-1 == fd){
        //perror("open device file error");
        return -9999;
    }

    while(1){
        ret = read(fd, buf, 128);
        if(0 == ret){
            break;  
        }
        if(-1 == ret){
            if(errno == EINTR){
                continue;   
            }
            //perror("read()");
            close(fd);
            return -9999;
        }
    }

    for(i=0;i<sizeof(buf);i++){
        if(buf[i] == 't'){
            for(j=0;j<sizeof(tempBuf);j++){
                tempBuf[j] = buf[i+2+j];    
            }
        }   
    }

    temp = (float)atoi(tempBuf) / 1000;
    if(temp >= Ref_Value) led_control(1);
    else led_control(0);
    //fprintf(stdout,"%.3f C\n",temp);
    close(fd);
    return temp;
}

// basic check that the time offset value is at ISO 8601 format
// bug: +12:30 is considered a valid value by this function


static uint8_t prv_set_value(lwm2m_data_t * dataP,
                             device_data_t * devDataP)
{
    // a simple switch structure is used to respond at the specified resource asked
    switch (dataP->id)
    {

    case RES_O_SENSOR_TEMP:
        lwm2m_data_encode_float(PRV_SENSOR_TEMP, dataP);
        return COAP_205_CONTENT;

    case RES_O_LIGHT_STATE:
        lwm2m_data_encode_int(PRV_LIGHT_STATE, dataP);
        return COAP_205_CONTENT;

    case RES_O_REFERENCE_VALUE:
        lwm2m_data_encode_int(PRV_REFERENCE_VALUE, dataP);
        return COAP_205_CONTENT; 
    default:
        return COAP_404_NOT_FOUND;
    }
}

static uint8_t prv_device_read(uint16_t instanceId,
                               int * numDataP,
                               lwm2m_data_t ** dataArrayP,
                               lwm2m_object_t * objectP)
{
    uint8_t result;
    int i;

    // this is a single instance object
    if (instanceId != 0)
    {
        return COAP_404_NOT_FOUND;
    }

    // is the server asking for the full object ?
    if (*numDataP == 0)
    {
        uint16_t resList[] = {
                RES_O_SENSOR_TEMP,
                RES_O_LIGHT_STATE,
                RES_O_REFERENCE_VALUE
        };
        int nbRes = sizeof(resList)/sizeof(uint16_t);

        *dataArrayP = lwm2m_data_new(nbRes);
        if (*dataArrayP == NULL) return COAP_500_INTERNAL_SERVER_ERROR;
        *numDataP = nbRes;
        for (i = 0 ; i < nbRes ; i++)
        {
            (*dataArrayP)[i].id = resList[i];
        }
    }

    i = 0;
    do
    {
        result = prv_set_value((*dataArrayP) + i, (device_data_t*)(objectP->userData));
        i++;
    } while (i < *numDataP && result == COAP_205_CONTENT);

    return result;
}

static uint8_t prv_device_discover(uint16_t instanceId,
                                   int * numDataP,
                                   lwm2m_data_t ** dataArrayP,
                                   lwm2m_object_t * objectP)
{
    uint8_t result;
    int i;

    // this is a single instance object
    if (instanceId != 0)
    {
        return COAP_404_NOT_FOUND;
    }

    result = COAP_205_CONTENT;

    // is the server asking for the full object ?
    if (*numDataP == 0)
    {
        uint16_t resList[] = {
                RES_O_SENSOR_TEMP,
                RES_O_LIGHT_STATE,
                RES_O_REFERENCE_VALUE
        };
        int nbRes = sizeof(resList) / sizeof(uint16_t);

        *dataArrayP = lwm2m_data_new(nbRes);
        if (*dataArrayP == NULL) return COAP_500_INTERNAL_SERVER_ERROR;
        *numDataP = nbRes;
        for (i = 0; i < nbRes; i++)
        {
            (*dataArrayP)[i].id = resList[i];
        }
    }
    else
    {
        for (i = 0; i < *numDataP && result == COAP_205_CONTENT; i++)
        {
            switch ((*dataArrayP)[i].id)
            {
            case RES_O_SENSOR_TEMP:
            case RES_O_LIGHT_STATE:
            case RES_O_REFERENCE_VALUE:
                break;
            default:
                result = COAP_404_NOT_FOUND;
            }
        }
    }

    return result;
}

static uint8_t prv_device_write(uint16_t instanceId,
                                int numData,
                                lwm2m_data_t * dataArray,
                                lwm2m_object_t * objectP)
{
    int i;
    uint8_t result;

    // this is a single instance object
    if (instanceId != 0)
    {
        return COAP_404_NOT_FOUND;
    }

    i = 0;

    do
    {
        switch (dataArray[i].id)
        {
        case RES_O_LIGHT_STATE:
            if (1 == lwm2m_data_decode_int(dataArray + i, &((device_data_t*)(objectP->userData))->state))
            {
                LedState = ((device_data_t*)(objectP->userData))->state;
                led_control(LedState);
                result = COAP_204_CHANGED;
            }
            else
            {
                result = COAP_400_BAD_REQUEST;
            }
            break;

        case RES_O_REFERENCE_VALUE:
            if (1 == lwm2m_data_decode_int(dataArray + i, &((device_data_t*)(objectP->userData))->reference))
            {
                Ref_Value = ((device_data_t*)(objectP->userData))->reference;
                result = COAP_204_CHANGED;
            }
            else
            {
                result = COAP_400_BAD_REQUEST;
            }
            break;

        default:
            result = COAP_405_METHOD_NOT_ALLOWED;
        }

        i++;
    } while (i < numData && result == COAP_204_CHANGED);

    return result;
}

static uint8_t prv_device_execute(uint16_t instanceId,
                                  uint16_t resourceId,
                                  uint8_t * buffer,
                                  int length,
                                  lwm2m_object_t * objectP)
{
    // this is a single instance object
    if (instanceId != 0)
    {
        return COAP_404_NOT_FOUND;
    }

    if (length != 0) return COAP_400_BAD_REQUEST;

    return COAP_405_METHOD_NOT_ALLOWED;
}

lwm2m_object_t * get_object_light_control()
{
    /*
     * The get_object_device function create the object itself and return a pointer to the structure that represent it.
     */
    lwm2m_object_t * deviceObj;

    deviceObj = (lwm2m_object_t *)lwm2m_malloc(sizeof(lwm2m_object_t));

    if (NULL != deviceObj)
    {
        memset(deviceObj, 0, sizeof(lwm2m_object_t));

        /*
         * It assigns his unique ID
         * The 3 is the standard ID for the mandatory object "Object device".
         */
        deviceObj->objID = LWM2M_LIGHT_CONTROL_OBJECT_ID;

        /*
         * and its unique instance
         *
         */
        deviceObj->instanceList = (lwm2m_list_t *)lwm2m_malloc(sizeof(lwm2m_list_t));
        if (NULL != deviceObj->instanceList)
        {
            memset(deviceObj->instanceList, 0, sizeof(lwm2m_list_t));
        }
        else
        {
            lwm2m_free(deviceObj);
            return NULL;
        }
        
        /*
         * And the private function that will access the object.
         * Those function will be called when a read/write/execute query is made by the server. In fact the library don't need to
         * know the resources of the object, only the server does.
         */
        deviceObj->readFunc     = prv_device_read;
        deviceObj->discoverFunc = prv_device_discover;
        deviceObj->writeFunc    = prv_device_write;
        deviceObj->executeFunc  = prv_device_execute;
        deviceObj->userData = lwm2m_malloc(sizeof(device_data_t));

        /*
         * Also some user data can be stored in the object with a private structure containing the needed variables 
         */
        if (NULL != deviceObj->userData)
        {
        }
        else
        {
            lwm2m_free(deviceObj->instanceList);
            lwm2m_free(deviceObj);
            deviceObj = NULL;
        }
    }

    return deviceObj;
}

void free_object_light_control(lwm2m_object_t * objectP)
{
    if (NULL != objectP->userData)
    {
        lwm2m_free(objectP->userData);
        objectP->userData = NULL;
    }
    if (NULL != objectP->instanceList)
    {
        lwm2m_free(objectP->instanceList);
        objectP->instanceList = NULL;
    }

    lwm2m_free(objectP);
}

