// host = '172.16.153.122';	// hostname or IP address
host = '127.0.0.1'; // hostname or IP address
// host = '172.16.153.110';	// hostname or IP address
port = 9001;
topic = 'mytopic'; // topic to subscribe 
useTLS = false;
username = null;
password = null;
// username = "jjolie";
// password = "aa";

// path as in "scheme:[//[user:password@]host[:port]][/]path[?query][#fragment]"
//    defaults to "/mqtt"
//    may include query and fragment
//
// path = "/mqtt";
// path = "/data/cloud?device=12345";

cleansession = true;