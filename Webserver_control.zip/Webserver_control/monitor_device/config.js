host = '127.0.0.1'; // hostname or IP address
port = 9001;
topic = 'mytopic';
useTLS = false;
username = admin;
password = admin;

// path as in "scheme:[//[user:password@]host[:port]][/]path[?query][#fragment]"
//    defaults to "/mqtt"
//    may include query and fragment
//
// path = "/mqtt";
// path = "/data/cloud?device=12345";

cleansession = true;