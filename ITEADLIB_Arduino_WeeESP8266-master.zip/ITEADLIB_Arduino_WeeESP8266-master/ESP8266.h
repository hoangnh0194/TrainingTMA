
#ifndef __ESP8266_H__
#define __ESP8266_H__

#include "Arduino.h"


#define ESP8266_USE_SOFTWARE_SERIAL


#ifdef ESP8266_USE_SOFTWARE_SERIAL
#include "SoftwareSerial.h"
#endif


class ESP8266 {
 public:

#ifdef ESP8266_USE_SOFTWARE_SERIAL

    ESP8266(SoftwareSerial &uart, uint32_t baud = 115200);
#else /* HardwareSerial */

    ESP8266(HardwareSerial &uart, uint32_t baud = 9600);
#endif
      
    
    uint32_t recv(uint8_t *buffer, uint32_t buffer_size, uint32_t timeout);
    
    uint32_t recv(uint8_t mux_id, uint8_t *buffer, uint32_t buffer_size, uint32_t timeout );
    
    uint32_t recv(uint8_t *coming_mux_id, uint8_t *buffer, uint32_t buffer_size, uint32_t timeout ,String remote_IP, int remote_port);
  
    void rx_empty(void);

    bool rx_receive(void);//
 
    String recvString(String target, uint32_t timeout = 1000);
    
    String recvString(String target1, String target2, uint32_t timeout = 1000);
   
    String recvString(String target1, String target2, String target3, uint32_t timeout = 1000);

    bool recvFind(String target, uint32_t timeout = 1000);
    
    bool recvFindAndFilter(String target, String begin, String end, String &data, uint32_t timeout = 1000);

    uint32_t recvPkg(uint8_t *buffer, uint32_t buffer_size, uint32_t *data_len, uint32_t timeout, uint8_t *coming_mux_id, String remote_IP, int remote_port);
    
////AT command function   
    bool eAT_Check(void);//check module 
    bool eAT_Restart(void);//restart module
    bool eAT_Version(String &version);//check firmware version
    
    bool qAT_Wifimode(uint8_t *mode);//query wifi mode as 
    bool sAT_Wifimode(uint8_t mode);//setup wifi mode(Access point/Station/both)
    bool sAT_Wificonnect(String ssid, String pwd);//connect to AP
    bool sAT_DHCP(uint8_t mode, bool enabled);//enable/disable DHCP
    bool eAT_CWLAP(String &list);
    bool eAT_CWQAP(void);
    bool sAT_SetupAP(String ssid, String pwd, uint8_t chl, uint8_t ecn);//setup SSID and PASS for module as AP
    bool eAT_CWLIF(String &list);//show list of joined station
    
    bool eAT_EnableShowRemote(uint8_t mode);//added function to control show remote IP & port

    bool eAT_checkConnectionStatus(String &list);//check connection status
    bool sAT_StartSingleServer(String type, String raddr, uint32_t rport);//start single connection server
    bool sAT_StartMultiServer(uint8_t mux_id, String type, String raddr, uint32_t rport);//start multi connection
    bool sAT_SendSingle(const uint8_t *buffer, uint32_t len);//send via single connection
    bool sAT_SendMulti(uint8_t mux_id, const uint8_t *buffer, uint32_t len);//send via multi connection
    bool sAT_CloseMulti(uint8_t mux_id);//close
    bool eAT_CloseSingle(void);
    bool eAT_ShowLocalIP(String &list);//show IP as AP or Station
    bool sAT_CIPMUX(uint8_t mode);//enable multi connection for init multi connection
    bool sAT_CIPSERVER(uint8_t mode, uint32_t port);//Start server from port
    bool sAT_CIPSTO(uint32_t timeout);//
private:
#ifdef ESP8266_USE_SOFTWARE_SERIAL
    SoftwareSerial *m_puart; /* The UART to communicate with ESP8266 */
#else
    HardwareSerial *m_puart; /* The UART to communicate with ESP8266 */
#endif
};

#endif /* #ifndef __ESP8266_H__ */

