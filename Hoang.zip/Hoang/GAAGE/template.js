

function RelayOnOff(indexrelay,idimg)
   { if(RelayState[parseInt(indexrelay)]=='0')//chuyen off sang on  //parseInt chuyen string sang so
       {
	    RelayState[parseInt(indexrelay)]='1';	   
		startRequest('relays.cgi?relay'+indexrelay+'=1',0);
	    SwitchImgOnOff(idimg,'1');
	   }
	   else if(RelayState[parseInt(indexrelay)]=='1')
	   {
	    RelayState[parseInt(indexrelay)]='0';
	    startRequest('relays.cgi?relay'+indexrelay+'=0',0);
	    SwitchImgOnOff(idimg,'0');
	   }
   }
   
function SwitchImgOnOff(id,onoff)
{

		if (onoff=='0') 
		{
			document.getElementById(id).className=document.getElementById(id).className.replace(/^on$/,"");
		} else 
		{
			document.getElementById(id).className ='on';
		}
}
function SwitchImgDeviceState(idimg,idtext,state)
{

		if (state=='0') 
		{
		    document.getElementById(idimg).className=document.getElementById(idimg).className.replace(/^er$/,"");
			document.getElementById(idimg).className=document.getElementById(idimg).className.replace(/^on$/,"");
			document.getElementById(idtext).innerHTML="State : OFF";
		} 
		else if(state=='1')
		{
		    document.getElementById(idimg).className=document.getElementById(idimg).className.replace(/^er$/,"");
			document.getElementById(idimg).className ='on';
			document.getElementById(idtext).innerHTML="State : ON";
		}
		else if(state=='2')
		{
		 document.getElementById(idimg).className=document.getElementById(idimg).className.replace(/^on$/,"");
			document.getElementById(idimg).className ='er';
			document.getElementById(idtext).innerHTML="State : ERROR";
		}
}

function AddOption(value,ID) {
    var x = document.getElementById(ID);
    var option = document.createElement("option");
    option.text = value;
    x.add(option);
}

function RemoveOption(value,ID) {
    var x = document.getElementById(ID);
	if(value=="all")
	{
	 var tem=x.length-1;
	 for(var i=0;i<tem;i++)
	 {
	 x.remove(1);
	 }
	 //x.remove(i);
	}
	else
   {
	for(var i=0;i<x.length;i++)
	{
	if(x.options[i].value==value)
	 {
	 x.remove(i);
	 }
	}
   }   
}
function Mymsg (msg)
{
var alt = document.createElement("div");

alt.setAttribute("id","mymessenger");
alt.innerHTML = 'ThÃ´ng bÃ¡o:</br>'+msg;
setTimeout(function(){
alt.parentNode.removeChild(alt);
},3000);
document.body.appendChild(alt);
}
//cac ham cho cua bao mat
/////////////////////////////////////////////////////
function DoorSwitchSecurity()
{
  if(DoorSwSecurity=='0')
  {
   DoorSwSecurity='1';
   SwitchImgOnOff('switchImage4','1');
   startRequest('doors?swsecuritydoor=1',0);
  }
else  
 {
	DoorSwSecurity='0';
	SwitchImgOnOff('switchImage4','0');
	startRequest('doors?swsecuritydoor=0',0);
 }
}
function OpenDoor()
{
	if(passwordopen.value=="")
	{
	 Mymsg("Báº¡n chÆ°a nháº­p máº­t kháº©u Ä‘á»ƒ má»Ÿ khÃ³a"); return;
	}
	startRequest('doors?opendoor='+passwordopen.value,0);
}
function CloseDoor()
{
	startRequest('doors?closedoor=1',0);
}
function ChangePass()
{

	if(oldpassword.value=="")
	{
	  Mymsg("Báº¡n chÆ°a nháº­p máº­t kháº©u cÅ©"); return;
	}
	if(newpassword.value=="")
	{
	 Mymsg("Báº¡n chÆ°a nháº­p máº­t kháº©u má»›i"); return;
	}
	if(confirmpassword.value=="")
	{
	 Mymsg("Báº¡n chÆ°a xÃ¡c nháº­n máº­t kháº©u má»›i"); return;
	}
	if(confirmpassword.value !=newpassword.value)
	{
	confirmpassword.value=""
	Mymsg("Máº­t kháº©u xÃ¡c nháº­n pháº£i trÃ¹ng vá»›i máº­t kháº©u má»›i"); return;	
	}
	var strt=confirmpassword.value;
    var letterNumber = /^[0-9a-zA-Z]+$/;  
    if(strt.match(letterNumber))   
    {  
      startRequest('doors?changepass='+oldpassword.value+'&newpassword='+newpassword.value,0); 
    } 
	else
	{
	Mymsg("Máº­t kháº©u chá»‰ bao gá»“m chá»¯ vÃ  sá»‘"); return;		
	}

	
}
function BtChangepassWord() {
    var x = document.getElementById('ChangepassWord');
    if (x.style.display === 'none') {
        x.style.display = 'block';
    } else {
        x.style.display = 'none';
    }
}

function SwitchImgDoorState(state)
{

		if (state=="0") 
		{
		    document.getElementById("imagedoor").className=document.getElementById("imagedoor").className.replace(/^open$/,"");
			document.getElementById("imagedoor").className=document.getElementById("imagedoor").className.replace(/^alarm$/,"");
			document.getElementById("textstatedoor").innerHTML="Tráº¡ng thÃ¡i cá»­a: "+StateDoor[parseInt(state)];
		} 
		else if(state=="1")
		{
		    document.getElementById("imagedoor").className=document.getElementById("imagedoor").className.replace(/^alarm$/,"");
			document.getElementById("imagedoor").className ='open';
			document.getElementById("textstatedoor").innerHTML="Tráº¡ng thÃ¡i cá»­a: "+StateDoor[parseInt(state)];
		}
		else if(state=="2")
		{
		 document.getElementById("imagedoor").className=document.getElementById("imagedoor").className.replace(/^open$/,"");
		 document.getElementById("imagedoor").className ='alarm';
		 document.getElementById("textstatedoor").innerHTML="Tráº¡ng thÃ¡i cá»­a: "+StateDoor[parseInt(state)];
		}
}
//ham xu ly an hien password
function ShowHide(nameclass,Idcheckbox)
{
var myclass=document.getElementsByClassName(nameclass);
var i = myclass.length;
while(i--)
{
 if(document.getElementById(Idcheckbox).checked==true)
    myclass[i].setAttribute("type", "text");
//document.getElementById('passwordopen').setAttribute("type", "text");
 else
    myclass[i].setAttribute("type", "password");
//document.getElementById('passwordopen').setAttribute("type", "password");
}

}
