<?php
function PrintAllClient($conn){
    $sql = "SELECT *  FROM client";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        // output data of each row
        while($row = $result->fetch_assoc()) {
            PrintSingle($row["name"]);
        }
    } else {
        echo "0 results";
    }
}
function PrintSingle($clientID){
	echo '
    <table style="width: 100%; text-align: center;" border="2">
    <tr>
        <th colspan="5">
            <h2>Client number: '.$clientID.' </h2>
            <h2>State: OFFLINE </h2>
            <button id="btCheck">CheckState</button>
        </th>
    </tr>
    <tr>
        <th colspan="4">Control Devices</th>
        <th>Monitor Sensors</th>
    </tr>
    <tr>
        <td>
            <button id="button1" >Light1</button>
            <div><b>State: </b><b>Curent:</b></div>
        </td>
        <td>
            <button id="button2">Light2</button>
            <div><b>State: </b><b>Curent:</b></div>
        </td>
        <td>
            <button id="button3">Light3</button>
            <div><b>State: </b><b>Curent:</b></div>
        </td>
        <td>
            <button id="button4">Door</button>
            <div><b>State: </b><b>Curent:</b></div>
        </td>
        <td style="width: 50%" rowspan="2">
            <canvas id="mycanvas1" width="500" height="100"></canvas>
            <canvas id="mycanvas2" width="500" height="100""></canvas>
        </td>
    </tr>
    <tr>
        <td colspan="2">
            <button id=".olumm1">VOL1</button>  
            <div id="slider1"></div>
        </td>
        <td colspan="2">
            <button id="volumm2">VOL2</button> 
            <div id="slider2"></div>
        </td>
    </tr>
    </table>
    </li>';
}
?>