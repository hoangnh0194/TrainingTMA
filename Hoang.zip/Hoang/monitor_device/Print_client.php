<?php

function PrintAllClient($conn){
    $sql = "SELECT *  FROM client";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        // output data of each row
        while($row = $result->fetch_assoc()) {
            PrintSingle($row["name"]);
        }
    } else {
        echo "0 results";
    }
}
function PrintSingle($clientID){
	echo '
    <table style="width: 100%; text-align: center;" border="2">
    <tr>
        <th colspan="5">
            <h3>Client number: '.$clientID.' </h3>
            <h3>State: OFFLINE </h3>
            <button id="/'.$clientID.'/btnCheck" class="check">CheckState</button>
        </th>
    </tr>
    <tr>
        <th colspan="4">Control Devices</th>
        <th>Monitor Sensors</th>
    </tr>
    <tr>
        <td>
            <button id="/'.$clientID.'/button1" class="btn1">Switch1</button>
            <div><b>State: </b><b>Curent:</b></div>
        </td>
        <td>
            <button id="/'.$clientID.'/button2" class="btn2">Switch2</button>
            <div><b>State: </b><b>Curent:</b></div>
        </td>
        <td>
            <button id="/'.$clientID.'/button3" class="btn3">Switch3</button>
            <div><b>State: </b><b>Curent:</b></div>
        </td>
        <td>
            <button id="/'.$clientID.'/button4" class="btn4">Switch4</button>
            <div><b>State: </b><b>Curent:</b></div>
        </td>
        <td style="width: 50%" rowspan="2">
            <canvas id="mycanvas1" width="500" height="100"></canvas>
            <canvas id="mycanvas2" width="500" height="100""></canvas>
        </td>
    </tr>
    <tr>
        <td colspan="2">
            <button id="/'.$clientID.'/volumm1" class="vol1">Vol1</button>  
            <div id="slider1"></div>
        </td>
        <td colspan="2">
            <button id="/'.$clientID.'/volumm2" class="vol2">Vol2</button> 
            <div id="slider2"></div>
        </td>
    </tr>
    </table>';
}


?>