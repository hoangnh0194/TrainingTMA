var mqtt;
var reconnectTimeout = 500;

function MQTTconnect() {
    if (typeof path == "undefined") {
        path = '/mqtt';
    }
    mqtt = new Paho.MQTT.Client(
        host,
        port,
        path,
        "web_" + parseInt(Math.random() * 100, 10)
        );
    var options = {
        timeout: 3,
        useSSL: useTLS,
        cleanSession: cleansession,
        onSuccess: onConnect,
        onFailure: function(message) {
            $('#status').val("Connection failed: " + message.errorMessage + "Retrying");
            setTimeout(MQTTconnect, reconnectTimeout);
        }
    };

    mqtt.onConnectionLost = onConnectionLost;
    mqtt.onMessageArrived = onMessageArrived;

    if (username != null) {
        options.userName = username;
        options.password = password;
    }
    console.log("Host=" + host + ", port=" + port + ", path=" + path + " TLS = " + useTLS + " username=" + username + " password=" + password);
    mqtt.connect(options);
}

function onConnect() {
            //alert("connect successful")
    mqtt.subscribe(topic, {qos: 0});
    // $('#button1').click(function(){
    //     message = new Paho.MQTT.Message("{light:ON}");
    //     message.destinationName = topic1;
    //     mqtt.send(message);
    // })
    // $('#button2').click(function(){
    //     senToClient(topic1,"{light:OFF}");
    // })            
    // $('#button3').click(function(){
    // })           
    // $('#button4').click(function(){
    // })
}

function onConnectionLost(response) {
    setTimeout(MQTTconnect, reconnectTimeout);
            //alert("connect fail")
};

function onMessageArrived(message) {
    var payload = message.payloadString;
    alert(payload)
            // obj = JSON.parse(payload);
            // if(obj.client = "client1" ){
            //     alert("client1 submit data")
            // }
    senToClient("client1","OK ngon");
};
         
function senToClient(desAddress,sentMessage){
    mess = new Paho.MQTT.Message(sentMessage);
    mess.destinationName = desAddress;
    mqtt.send(mess);
}

// function handle_init_client(clientID){
//     if (window.XMLHttpRequest) {
//             // code for IE7+, Firefox, Chrome, Opera, Safari
//         xmlhttp = new XMLHttpRequest();
//     } else {
//             // code for IE6, IE5
//         xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
//     }
//     xmlhttp.onreadystatechange = function(){
//         if(this.readyState ==4 && this.status == 200){
//             document.getElementById("client_show_site").innerHTML = this.responseText;
//         }
//     };
//     xmlhttp.open("GET","Print_client.php?para"+clientID,true);
//     xmlhttp.send();
// }

function showChart(){
    var smoothie1 = new SmoothieChart({interpolation:'linear', grid:{fillStyle:'#96c5c5'}}),
        line1 = new TimeSeries();
    setInterval(function() {
        line1.append(Date.now(),2);
                                }, 500);
    smoothie1.addTimeSeries(line1,{lineWidth: 4 });
    smoothie1.streamTo(document.getElementById("mycanvas1"),500);

    var smoothie2 = new SmoothieChart({interpolation:'linear', grid:{fillStyle:'#96c5c5'}}),
        line2 = new TimeSeries();
    setInterval(function() {
        line2.append(Date.now(), Math.random() * 100);}, 500);
    smoothie2.addTimeSeries(line2,{lineWidth: 4 });
    smoothie2.streamTo(document.getElementById("mycanvas2"),500);
}

// $("li").each(function(){
//     $('#button1').click(function(){
//         message = new Paho.MQTT.Message("{light:ON}");
//         message.destinationName = topic1;
//         mqtt.send(message);
//     })
//     $('#button2').click(function(){
//         senToClient(topic1,"{light:OFF}");
//     })            
//     $('#button3').click(function(){
//     })           
//     $('#button4').click(function(){
//     })  
// });


function refrClock() {
    var d=new Date();
    var s=d.getSeconds();
    var m=d.getMinutes();
    var h=d.getHours();
    var day=d.getDay();
    var date=d.getDate();
    var month=d.getMonth();
    var year=d.getFullYear();
    var days=new Array("Sunday","Monday","Tueday","Wednesday","Thursday","Friday","Saturday");
    var months=new Array("1","2","3","4","5","6","7","8","9","10","11","12"); 
    var am_pm;
        if (s<10) {s="0" + s}
        if (m<10) {m="0" + m}
        if (h>12){h-=12;AM_PM = "PM"}
        else {AM_PM="AM"}
        if (h<10) {h="0" + h}
    document.getElementById("clock").innerHTML=days[day] + " " + date + "/" +months[month] + "/" + year + " [" + h + ":" + m + ":" + s + "] " + AM_PM; 
    setTimeout("refrClock()",1000); 
} 
$(document).ready(function() {
    MQTTconnect();
    refrClock();
});