<?php
    include '../core/sql/sql-function.php';
    $conn = ConnectDatabse(); 

    $clientID = $_POST["clientID"];
    $name = $_POST["name"];
    $state = $_POST["state"];
    $amp = $_POST["amp"];

    $sql = "UPDATE " . $table . "SET state=" . $state ." WHERE client='$objClient',name='$name'";
	echo $sql . PHP_EOL;
	if ($conn->query($sql) === TRUE)
	    echo "<script> alert("Record updated successfully") </script>" . PHP_EOL ;
	else
	    echo "Error updating record: " . $conn->error . PHP_EOL;
?>