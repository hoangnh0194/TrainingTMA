//host = '192.168.1.5';	// hostname or IP address of Pi3
host = 'localhost'; // hostname or IP address
//host = 'iot.eclipse.org';	// hostname or IP address
port = 9001;
//port = 443;
topic = 'mytopic'; // topic to subscribe from webserver
topic1 = 'client1';//topic to subcribe from client 1
topic2 = 'client2';//topic to subcribe from client 2
useTLS = false;
username = null;
password = null;
path = "/ws";

cleansession = true;