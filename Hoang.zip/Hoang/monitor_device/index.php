<?php
session_start();
include '../core/sql/sql-function.php';

$conn = ConnectDatabse();
?>

<!DOCTYPE html>
<html>

<head>
    <title>Monitor_device</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script src="../core/mosquitto/mqttws31.js" type="text/javascript"></script>
    <script src="../core/jquery/jquery.min.js" type="text/javascript"></script>
    <script src="config.js" type="text/javascript"></script>

    <script type="text/javascript">
        var mqtt;
        var reconnectTimeout = 2000;

        function MQTTconnect() {
            if (typeof path == "undefined") {
                path = '/mqtt';
            }
            mqtt = new Paho.MQTT.Client(
                host,
                port,
                path,
                "web_" + parseInt(Math.random() * 100, 10)
            );
            var options = {
                timeout: 3,
                useSSL: useTLS,
                cleanSession: cleansession,
                onSuccess: onConnect,
                onFailure: function(message) {
                    $('#status').val("Connection failed: " + message.errorMessage + "Retrying");
                    setTimeout(MQTTconnect, reconnectTimeout);
                }
            };

            mqtt.onConnectionLost = onConnectionLost;
            mqtt.onMessageArrived = onMessageArrived;

            if (username != null) {
                options.userName = username;
                options.password = password;
            }
            console.log("Host=" + host + ", port=" + port + ", path=" + path + " TLS = " + useTLS + " username=" + username + " password=" + password);
            mqtt.connect(options);
        }

        function onConnect() {
            alert("connect successful")
            // $('#status').val('Connected to ' + host + ':' + port + path);
            // Connection succeeded; subscribe to our topic
            mqtt.subscribe(topic, {
                qos: 0
            });
            // $('#topic').val(topic);
            $('#button1').click(function(){
                message = new Paho.MQTT.Message("{light:ON}");
                message.destinationName = topic1;
                mqtt.send(message);
            })
            $('#button2').click(function(){
                message = new Paho.MQTT.Message("{light:OFF}");
                message.destinationName = topic1;
                mqtt.send(message);
            })            
            $('#button3').click(function(){
                message = new Paho.MQTT.Message("{door:OPEN}");
                message.destinationName = topic2;
                mqtt.send(message);
            })           
            $('#button4').click(function(){
                message = new Paho.MQTT.Message("{door:CLOSE}");
                message.destinationName = topic2;
                mqtt.send(message);
            })
        }

        function onConnectionLost(response) {
            setTimeout(MQTTconnect, reconnectTimeout);
            alert("connect fail")
            // $('#status').val("connection lost: " + responseObject.errorMessage + ". Reconnecting");

        };

        function onMessageArrived(message) {

            var topic = message.destinationName;
            var payload = message.payloadString;
            // $('#ws').prepend('<li>' + topic + ' = ' + payload + '</li>');
        };


        $(document).ready(function() {
            MQTTconnect();
        });
    </script>
</head>

<body>
    <h1>House Smart Control</h1>
    <h2>Webserver on Raspberry Pi 3</h2>
    <hr style="width: 100%; height: 0px;">
    <div>
        <button id="button1">Light ON</button><button id="button2">Light OFF</button><button id="button3">Door OPEN</button><button id="button4">Door CLOSE</button>
        <!-- <div>Subscribed to <input type='text' id='topic' disabled /> Status: <input type='text' id='status' size="80" disabled /></div> -->

        <!-- <ul id='ws' style="font-family: 'Courier New', Courier, monospace;"></ul> -->
    </div>
    <hr style="width: 100%; height: 0px;">

<?php 
  if (isset($_SESSION['user']) && isset($_SESSION['pass']))
    echo $_SESSION['user'];
  else
  {
    header("location:../index.php");
  }
?>

    <a href="../login/logout.php" > Logout </a>
  </body>
</body>

</html>
<?php 
    CloseDatabase($conn);
?>