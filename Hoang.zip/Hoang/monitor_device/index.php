<?php
    session_start();
    include '../core/sql/sql-function.php';

    $conn = ConnectDatabse();


?>

<!DOCTYPE html>
<html>

<head>
    <title>Monitor_device</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script src="../core/mosquitto/mqttws31.js" type="text/javascript"></script>
    <script src="../core/jquery/jquery.min.js" type="text/javascript"></script>
    <script src="../core/smoothie/smoothie.js" type="text/javascript"></script>
    <script src="config.js" type="text/javascript"></script>

    <script type="text/javascript">
        var mqtt;
        var reconnectTimeout = 2000;

        function MQTTconnect() {
            if (typeof path == "undefined") {
                path = '/mqtt';
            }
            mqtt = new Paho.MQTT.Client(
                host,
                port,
                path,
                "web_" + parseInt(Math.random() * 100, 10)
            );
            var options = {
                timeout: 3,
                useSSL: useTLS,
                cleanSession: cleansession,
                onSuccess: onConnect,
                onFailure: function(message) {
                    $('#status').val("Connection failed: " + message.errorMessage + "Retrying");
                    setTimeout(MQTTconnect, reconnectTimeout);
                }
            };

            mqtt.onConnectionLost = onConnectionLost;
            mqtt.onMessageArrived = onMessageArrived;

            if (username != null) {
                options.userName = username;
                options.password = password;
            }
            console.log("Host=" + host + ", port=" + port + ", path=" + path + " TLS = " + useTLS + " username=" + username + " password=" + password);
            mqtt.connect(options);
        }

        function onConnect() {
            alert("connect successful")
            mqtt.subscribe(topic, {
                qos: 0
            });
            $('#button1').click(function(){
                message = new Paho.MQTT.Message("{light:ON}");
                message.destinationName = topic1;
                mqtt.send(message);
            })
            $('#button2').click(function(){
                message = new Paho.MQTT.Message("{light:OFF}");
                message.destinationName = topic1;
                mqtt.send(message);
            })            
            $('#button3').click(function(){
                message = new Paho.MQTT.Message("{door:OPEN}");
                message.destinationName = topic2;
                mqtt.send(message);
            })           
            $('#button4').click(function(){
                message = new Paho.MQTT.Message("{door:CLOSE}");
                message.destinationName = topic2;
                mqtt.send(message);
            })
        }

        function onConnectionLost(response) {
            setTimeout(MQTTconnect, reconnectTimeout);
            alert("connect fail")
        };

        function onMessageArrived(message) {

            var topic = message.destinationName;
            var payload = message.payloadString;
        };

        function showChart(){
            var smoothie1 = new SmoothieChart({interpolation:'linear'});
            smoothie1.streamTo(document.getElementById("mycanvas1"));
            var smoothie2 = new SmoothieChart({interpolation:'linear'});
            smoothie2.streamTo(document.getElementById("mycanvas2"));
        }

        function refrClock() {
                        var d=new Date();
                        var s=d.getSeconds();
                        var m=d.getMinutes();
                        var h=d.getHours();
                        var day=d.getDay();
                        var date=d.getDate();
                        var month=d.getMonth();
                        var year=d.getFullYear();
                        var days=new Array("Sunday","Monday","Tueday","Wednesday","Thursday","Friday","Saturday");
                        var months=new Array("1","2","3","4","5","6","7","8","9","10","11","12"); 
                        var am_pm;
                        if (s<10) {s="0" + s}
                        if (m<10) {m="0" + m}
                        if (h>12){h-=12;AM_PM = "PM"}
                        else {AM_PM="AM"}
                        if (h<10) {h="0" + h}
            document.getElementById("clock").innerHTML=days[day] + " " + date + "/" +months[month] + "/" + year + " [" + h + ":" + m + ":" + s + "] " + AM_PM; 
            setTimeout("refrClock()",1000); 
        } 
        $(document).ready(function() {
            MQTTconnect();
            showChart();
            refrClock();
        });
    </script>
</head>

<body>
    <h1 align="center">House Smart Control</h1>
    <h2 align="center">Webserver on Raspberry Pi 3</h2>
    <div id="divtitle" align="center">
        <hr style="width: 100%; height: 0px;">
        <a href="../main/main.php"><b class="textlink">MainPage</b></a>
        <!-- <a href="../control_device/index.php"><b class="textlink">DeviceControl</b></a> -->
        <a href="../monitor_device/index.php"><b class="textlink">DeviceMonitor</b></a>
        <hr style="width: 100%; height: 0px;">
    </div>

    <div>
    <table style="width: 100%; text-align: center;" border="1px">
    <tr>
        <td>
            <button id="button1" >Light1</button>
            <div><b>State: </b><b>Curent:</b></div>
        </td>
        <td>
            <button id="button2">Light2</button>
            <div><b>State: </b><b>Curent:</b></div>
        </td>
        <td>
            <button id="button3">Light3</button>
            <div><b>State: </b><b>Curent:</b></div>
        </td>
        <td>
            <button id="button4">Door</button>
            <div><b>State: </b><b>Curent:</b></div>
        </td>
    </tr>
    </table>
    </div>
    <hr style="width: 100%; height: 0px;">
    <canvas id="mycanvas1" width="750" height="100"></canvas>
    <canvas id="mycanvas2" width="750" height="100"></canvas>
    <hr style="width: 100%; height: 0px;">
    <div id="clock" align="center">Loading...</div>
    <hr style="width: 100%; height: 0px;">


<?php 
    if (isset($_SESSION['user']) && isset($_SESSION['pass']))
        echo $_SESSION['user'];
    else
    {
        header("location:../index.php");
    }
?>

    <a href="../login/logout.php" > Logout </a>
</body>

</html>
<?php 
    CloseDatabase($conn);
?>