<?php
    session_start();
    include '../core/sql/sql-function.php';
    include 'Print_client.php';

    $conn = ConnectDatabse();
?>

<!DOCTYPE html>
<html>

<head>
    <title>Monitor_device</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script src="../core/mosquitto/mqttws31.js" type="text/javascript"></script>
    <script src="../core/jquery/jquery.min.js" type="text/javascript"></script>
    <script src="../core/jquery/jquery-ui.js" type="text/javascript"></script>
    <!-- <script src="../core/bootstrap/bootstrap.min.js" type="text/javascript"></script> -->
    <link rel="stylesheet" type="text/css" href="../core/jquery/jquery-ui.min.css">
    <script src="../core/smoothie/smoothie.js" type="text/javascript"></script>
    <script src="config.js" type="text/javascript"></script>
    <script src="JScode.js" type="text/javascript"></script>
</head>

<body>
    <h1 align="center">Multiapplication Control box</h1>
    <h2 align="center">Webserver base on Raspberry Pi 3</h2>
    <div id="divtitle" align="center">
        <hr style="width: 100%; height: 0px;">
        <a href="../main/main.php"><b class="textlink">MainPage</b></a>
        <a href="../monitor_device/index.php"><b class="textlink">DeviceMonitor</b></a>
        <hr style="width: 100%; height: 0px;">
    </div>
    <ul id="client_show_site">
<?php 
    PrintAllClient($conn);
?>
    </ul>
    <hr style="width: 100%; height: 0px;">
    <div id="clock" align="center">Loading...</div>
    <hr style="width: 100%; height: 0px;">


<?php 
    if (isset($_SESSION['user']) && isset($_SESSION['pass']))
        echo $_SESSION['user'];
    else
    {
        header("location:../index.php");
    }
?>
    <a href="../login/logout.php" > Logout </a>
</body>

</html>
<?php 
    CloseDatabase($conn);
?>