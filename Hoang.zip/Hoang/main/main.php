<?php
    session_start();
?>

<!DOCTYPE html >
<html>

<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <title>House Smart Control</title>
</head>

<body>
    <div id="mainbody">
        <div id="divtitle" align="center">
            <h2>House Smart Control</h2>
            <h2>Webserver on Raspberry Pi 3</h2>
            <hr style="width: 100%; height: 0px;">
            <a href="../main/main.php"><b class="textlink">MainPage</b></a>
            <!-- <a href="../control_device/index.php"><b class="textlink">DeviceControl</b></a> -->
            <a href="../monitor_device/index.php"><b class="textlink">DeviceMonitor</b></a>
            <hr style="width: 100%; height: 0px;">
            <marquee><strong>Smart house with device controlling and monitoring via webserver builded on Raspberry Pi 3. Master-Clients comunication base on MQTT protocol</strong></marquee>
            <hr style="width: 100%; height: 0px;">
        </div>

        <div id="maincontent" align="center">
            <div id="divinformation">
                <div id="myschool">
                    <div style="text-align:center; width: 400px;">
                        <h4>ĐẠI HỌC QUỐC GIA THÀNH PHỐ HỒ CHÍ MINH</br>TRƯỜNG ĐẠI HỌC BÁCH KHOA</h4>
                    </div>
                    <div >
                        <img src="../core/Images/200px_Logo_hcmut.png">
                    </div>
                </div>
                <div id="myinformation">
                    <h2>LUẬN VĂN TỐT NGHIỆP ĐẠI HỌC</h2>
                    <p><strong>GVHD: LƯU PHÚ</strong></p>
                    <p><strong>SVTH: NGUYỄN HUY HOÀNG</br>MSSV: 41201214</strong></p>
                </div>
            </div>
            <div id="nameproject" style="text-align:center;">
                <h3>CONTROL AND MONITO HOUSE DEVICES FROM WEB SERVER</br>USING MQTT PROTOCOL</h3>
            </div>
        </div>
    </div>
    <hr style="width: 100%; height: 0px;">
    <div id="about-box" class="about">
        <p class="about_title">Author: Nguyễn Huy Hoàng</p>
    </div>
    <hr style="width: 100%; height: 0px;">


<?php 
if (isset($_SESSION['user']) && isset($_SESSION['pass']))
    echo $_SESSION['user'];
else
{
    header("location:../index.php");
}
?>
    <a href="../login/logout.php" > Logout </a>
</body>

</html>