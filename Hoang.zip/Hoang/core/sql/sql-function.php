<?php 
define("serverName", "localhost");
define("userName", "root");
define("password", "12345678");
define("dbName", "home");
define("TABLE", " device "); // need space between 'device'
define("TABLE1", " login ");
define("TABLE2", " sensor ");
function ConnectToSql() {
	$conn = mysqli_connect(serverName, userName, password);
	if (!$conn)
	    die("Connection failed: " . mysqli_connect_error()) . PHP_EOL;
	else;
	    echo "Connection to mysql success !" . PHP_EOL;
	return $conn;
}

function CloseSql($conn) {
	mysqli_close($conn);
}

// Create connection to database 'home'
function ConnectDatabse() {
	$conn = mysqli_connect(serverName, userName, password, dbName);
	// Check connection
	if (!$conn)
	    die("Connection failed: " . mysqli_connect_error());
	else;
		// echo "Connection database success !\n";
	return $conn;
}

// Disconnect to database
function CloseDatabase($conn) {
	mysqli_close($conn);
}

// function create a table if not exist
function CreateTable($conn, $table) {//type controlled device

	$tableName = $table;

	$sql = "CREATE TABLE IF NOT EXISTS $tableName (
		id INT(16) UNSIGNED AUTO_INCREMENT PRIMARY KEY, 
		type INT(8) UNSIGNED DEFAULT 0,
		name VARCHAR(50) NOT NULL,
		state BOOLEAN NOT NULL DEFAULT 0,
		amplitude INT(8) DEFAULT 0
	)";
	if (mysqli_query($conn, $sql)) {
	    echo "Empty table 'device' created successfully\n";
	} else {
	    echo "Error creating table: " . mysqli_error($conn);
	}
}

function CreateTable1($conn, $table) {//type data for username and password

	$tableName = $table;

	$sql = "CREATE TABLE IF NOT EXISTS $tableName (
		id INT(32) UNSIGNED AUTO_INCREMENT PRIMARY KEY, 
		username VARCHAR(50) NOT NULL,
	    password VARCHAR(50) NOT NULL
	)";
	if (mysqli_query($conn, $sql)) {
	    echo "Empty table 'login' created successfully\n";
	} else {
	    echo "Error creating table: " . mysqli_error($conn);
	}
}

function CreateTable2($conn, $table) {//type data sensors

	$tableName = $table;

	$sql = "CREATE TABLE IF NOT EXISTS $tableName (
		id INT(32) UNSIGNED AUTO_INCREMENT PRIMARY KEY, 
		temperature VARCHAR(10) NOT NULL,
	    humidity VARCHAR(10) NOT NULL,
	    current VARCHAR(10) NOT NULL
	)";
	if (mysqli_query($conn, $sql)) {
	    echo "Empty table 'sensor' created successfully\n";
	} else {
	    echo "Error creating table: " . mysqli_error($conn);
	}
}

// function insert object to table
function InsertObject($conn, $objType, $objName, $state, $amplitude) {
	
	$sql = "INSERT INTO " . TABLE . " (type, name, state, amplitude)
	VALUES ('$objType', '$objName', '$state', '$amplitude')";
	// echo $sql . PHP_EOL;
	if ($conn->query($sql) === TRUE)
	    echo "Create a new object successfully" . PHP_EOL;
	else
	    echo "Error: " . $sql . " : " . $conn->error . PHP_EOL;
}

function InsertObject1($conn, $objName, $objPass) {
	
	$sql = "INSERT INTO " . TABLE1 . " (username, password)
	VALUES ('$objName', '$objPass' )";
	// echo $sql . PHP_EOL;
	if ($conn->query($sql) === TRUE)
	    echo "Create a new object successfully" . PHP_EOL;
	else
	    echo "Error: " . $sql . " : " . $conn->error . PHP_EOL;
}

function InsertObject2($conn, $objTemp, $objHumid, $objCur) {
	
	$sql = "INSERT INTO " . TABLE2 . " (temperature, humidity, current)
	VALUES ('$objTemp', '$objHumid', '$objCur' )";
	// echo $sql . PHP_EOL;
	if ($conn->query($sql) === TRUE)
	    echo "Create a new object successfully" . PHP_EOL;
	else
	    echo "Error: " . $sql . " : " . $conn->error . PHP_EOL;
}
// Delete object 
// ex : DeleteObject($conn, "objName-light");
function DeleteObject($conn, $table, $objName) {///use for usename and device

	$sql = "DELETE FROM " . $table . " WHERE name='$objName' ";
	// echo $sql . PHP_EOL;
	if ($conn->query($sql) === TRUE)
	    echo "Record deleted successfully" . PHP_EOL;
	else
	    echo "Error deleting record: " . $conn->error . PHP_EOL;
}

// Update object
function UpdateObject($conn, $table, $objName, $propChange) {//use for device

	$sql = "UPDATE " . $table . " SET $propChange WHERE name='$objName' ";
	echo $sql . PHP_EOL;
	if ($conn->query($sql) === TRUE)
	    echo "Record updated successfully" . PHP_EOL ;
	else
	    echo "Error updating record: " . $conn->error . PHP_EOL;
}
//select data from database's table 
function SelectDevice($conn, $table, $objID, $objParam)
{
	$sql = "SELECT " . $objParam . " FROM $table WHERE id ='$objID'";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        return $row["$objParam"];
    } else {
        echo "0 results";
    }
}

?>