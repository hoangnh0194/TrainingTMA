<?php

include 'sql-function.php';

// Create connection
$conn = ConnectToSql();

// Create a new database
$sql = 'CREATE DATABASE IF NOT EXISTS ' . dbName .'';
if (mysqli_query($conn, $sql))
    echo "Database 'home' created successfully" . PHP_EOL;
else
    echo "Error creating database: " . mysqli_error($conn) . PHP_EOL;

// Select database
$sql = 'USE ' . dbName . '';
if ( !mysqli_query($conn, $sql))
    echo "Error use database: " . mysqli_error($conn) . PHP_EOL;

// sql to create table
CreateTable($conn, "device");
CreateTable1($conn, "login");
CreateTable2($conn, "sensor");
CreateTable3($conn, "client");

// Insert object to database
// ex ; InsertObject($conn,object-type,object-name,initial-state,color,amplitude,icon);

InsertObject1($conn,"admin", md5("admin"));
InsertObject1($conn, "Hoang",md5("123456"));
InsertObject3($conn, "clientNumber1");
InsertObject3($conn, "clientNumber2");
InsertObject($conn, "switch1",1,"clientNumber1",0,0);
InsertObject($conn, "switch2",1,"clientNumber1",0,0);
InsertObject($conn, "switch3",1,"clientNumber1",0,0);
InsertObject($conn, "switch4",1,"clientNumber1",0,0);
InsertObject($conn, "volumm1",2,"clientNumber1",0,0);
InsertObject($conn, "volumm2",2,"clientNumber1",0,0);
InsertObject($conn, "switch1",1,"clientNumber2",0,0);
InsertObject($conn, "switch2",1,"clientNumber2",0,0);
InsertObject($conn, "switch3",1,"clientNumber2",0,0);
InsertObject($conn, "switch4",1,"clientNumber2",0,0);
InsertObject($conn, "volumm1",2,"clientNumber2",0,0);
InsertObject($conn, "volumm2",2,"clientNumber2",0,0);
CloseSql($conn);

?>