<?php

include 'sql-function.php';

// Create connection
$conn = ConnectToSql();

// Create a new database
$sql = 'CREATE DATABASE IF NOT EXISTS ' . dbName .'';
if (mysqli_query($conn, $sql))
    echo "Database 'home' created successfully" . PHP_EOL;
else
    echo "Error creating database: " . mysqli_error($conn) . PHP_EOL;

// Select database
$sql = 'USE ' . dbName . '';
if ( !mysqli_query($conn, $sql))
    echo "Error use database: " . mysqli_error($conn) . PHP_EOL;

// sql to create table
CreateTable($conn, "device");
CreateTable1($conn, "login");
CreateTable2($conn, "sensor");

// Insert object to database
// ex ; InsertObject($conn,object-type,object-name,initial-state,color,amplitude,icon);
InsertObject($conn, 1 , "Switch Light 1", 0, 0);
InsertObject($conn, 1 , "Switch Light 2", 0, 0);
InsertObject($conn, 2 , "Dimmer 1", 0, 50);
InsertObject($conn, 2 , "Dimmer 2", 0, 50);

InsertObject1($conn,"admin", md5("admin"));
InsertObject1($conn, "Hoang",md5("123456"));
InsertObject1($conn, "Hoang0194",md5("123456"));


// Delete object to database
// DeleteObject($conn, "object-name");

// Update object
// UpdateObject($conn,"object-name","name='value'");

// Get object properties
// GetObject($conn);

CloseSql($conn);

?>