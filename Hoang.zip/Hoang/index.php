<!DOCTYPE html>
<html>
<head>
    <title>House Smart Control</title>
    <!-- Include CSS File Here -->
    <link rel="stylesheet" href="login/loginstyle.css" />

</head>

<script type="text/javascript">
    function Check(){
        if(document.myform.user.value==""){
            alert("Username cannot be blank!")
            document.frmlogin.user.focus();
            return false;
        }
        if(document.myform.pass.value==""){
            alert("Pass cannot be blank!")
            document.frmlogin.pass.focus();
            return false;
        }
        else return true;
    }
</script>

<body>
    <div class="container">
        <div class="main">
            <h2>Login Your User Account</h2>
            <form id="form_id" method="post" name="myform" method="POST" onsubmit="return Check()">
                <label>User Name :</label>
                <input type="text" name="user" id="user" />
                <label>Password :</label>
                <input type="password" name="pass" id="pass" />
                <input type="submit" value="Login" id="submit" name="submit" />
            </form>
        </div>
    </div>
</body>

</html>

<?php

session_start();
ob_start();

if(isset($_POST['submit'])){
// Define $username and $password 
    $user=$_POST['user']; 
    $pass=md5($_POST['pass']);

    if($user & $pass){
        // Connect to server and select databse.
        $conn = mysqli_connect("localhost", "root", "12345678" , "home") or die("Connect MySQL failed!");
        $result=mysqli_query($conn , "SELECT * FROM login WHERE username='$user' and password='$pass'");
        $row = mysqli_fetch_array($result);
    // If result matched $username and $password, table row must be 1 row
        if (mysqli_num_rows($result)==0) {
        echo "<script> alert('Username or Password go wrong!')</script>";
        } else {
            
        $_SESSION['user']=$user;
        $_SESSION['pass']=$pass;
        $_SESSION['hoten']=$row['HoTen'];

        header("location:main/main.php");
        }
    }
}
?>


