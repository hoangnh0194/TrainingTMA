<?php
session_start();
include 'function/print-HTML.php';
include '../core/sql/sql-function.php';

$conn = ConnectDatabse();
?>

<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />

    <title>Device Control</title>
    
    <!-- CSS -->
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Open+Sans">
    <link rel="stylesheet" type="text/css" href="../core/fonts/font-awesome/css/font-awesome.min.css">
    <!-- Bootstrap -->
    <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="css/jquery-ui.min.css">
    <link rel="stylesheet" type="text/css" href="css/index.css">

    <!-- JS -->
    <script type="text/javascript" src="../core/jquery/jquery.js"></script>
    <script type="text/javascript" src="../core/jquery/jquery-ui.min.js"></script>
    <script type="text/javascript" src="jquery/jquery.ui.touch-punch.min.js"></script>
    <script type="text/javascript" src="jquery/query.js"></script>

  </head>
  <body class="lazy-man">
    <div id="divtitle">
            <hr style="width: 100%; height: 0px;">
            <a href="../main/main.php"><b class="textlink">MainPage</b></a>
            <a href="../control_device/index.php"><b class="textlink">DeviceControl</b></a>
            <a href="../monitor_device/index.php"><b class="textlink">DeviceMonitor</b></a>
            <hr style="width: 100%; height: 0px;">
    </div>
    <!-- Fixed navbar -->
    <div class="container"></div>
    <nav class="navbar navbar-inverse navbar-fixed-top">
      <div class="container">
        <div class="navbar-header">
        </div>
      </div>
    </nav>
    <!-- Conainer -->
    <div class="container">

      <div class="row">
        <div class="land-1">
<?php

	PrintObjectDatabase($conn);
	PrintObjectSend();
  // PrintEverythingElse();

?>
          <div class="clearfix"></div>  
        </div>
      </div>
    </div>
	  <div class="log-box alert alert-danger" role="alert">
			<strong>Woop !</strong>
			<p class="log-text">test demo alert log</p>
		</div>
    <hr style="width: 100%; height: 0px;">

<?php 
  if (isset($_SESSION['user']) && isset($_SESSION['pass']))
    echo $_SESSION['user'];
  else
  {
    header("location:../index.php");
  }
?>
    <a href="../login/logout.php" > Logout </a>
  </body>

</html>

<?php 
	CloseDatabase($conn);
?>