﻿namespace ChillerControl
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn_connect = new System.Windows.Forms.Button();
            this.SelectPort = new System.Windows.Forms.ComboBox();
            this.Baudrate = new System.Windows.Forms.ComboBox();
            this.label2 = new System.Windows.Forms.Label();
            this.cps_start = new System.Windows.Forms.Button();
            this.cps_stop = new System.Windows.Forms.Button();
            this.tmp_stop = new System.Windows.Forms.Button();
            this.tmp_start = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.label1 = new System.Windows.Forms.Label();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.SuspendLayout();
            // 
            // btn_connect
            // 
            this.btn_connect.Location = new System.Drawing.Point(365, 27);
            this.btn_connect.Name = "btn_connect";
            this.btn_connect.Size = new System.Drawing.Size(75, 23);
            this.btn_connect.TabIndex = 0;
            this.btn_connect.Text = "Connect";
            this.btn_connect.UseVisualStyleBackColor = true;
            this.btn_connect.Click += new System.EventHandler(this.btn_connect_Click);
            // 
            // SelectPort
            // 
            this.SelectPort.FormattingEnabled = true;
            this.SelectPort.Location = new System.Drawing.Point(76, 27);
            this.SelectPort.Margin = new System.Windows.Forms.Padding(2);
            this.SelectPort.Name = "SelectPort";
            this.SelectPort.Size = new System.Drawing.Size(97, 21);
            this.SelectPort.TabIndex = 2;
            this.SelectPort.SelectedIndexChanged += new System.EventHandler(this.comboBox1_SelectedIndexChanged);
            // 
            // Baudrate
            // 
            this.Baudrate.FormattingEnabled = true;
            this.Baudrate.Location = new System.Drawing.Point(246, 29);
            this.Baudrate.Margin = new System.Windows.Forms.Padding(2);
            this.Baudrate.Name = "Baudrate";
            this.Baudrate.Size = new System.Drawing.Size(97, 21);
            this.Baudrate.TabIndex = 4;
            this.Baudrate.SelectedIndexChanged += new System.EventHandler(this.comboBox2_SelectedIndexChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(191, 32);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(50, 13);
            this.label2.TabIndex = 5;
            this.label2.Text = "Baudrate";
            // 
            // cps_start
            // 
            this.cps_start.BackColor = System.Drawing.Color.Green;
            this.cps_start.Location = new System.Drawing.Point(68, 19);
            this.cps_start.Name = "cps_start";
            this.cps_start.Size = new System.Drawing.Size(116, 37);
            this.cps_start.TabIndex = 7;
            this.cps_start.Text = "Start";
            this.cps_start.UseVisualStyleBackColor = false;
            this.cps_start.Click += new System.EventHandler(this.cps_start_Click);
            // 
            // cps_stop
            // 
            this.cps_stop.BackColor = System.Drawing.Color.Red;
            this.cps_stop.Location = new System.Drawing.Point(278, 19);
            this.cps_stop.Name = "cps_stop";
            this.cps_stop.Size = new System.Drawing.Size(108, 37);
            this.cps_stop.TabIndex = 8;
            this.cps_stop.Text = "Stop";
            this.cps_stop.UseVisualStyleBackColor = false;
            this.cps_stop.Click += new System.EventHandler(this.cps_stop_Click);
            // 
            // tmp_stop
            // 
            this.tmp_stop.BackColor = System.Drawing.Color.Red;
            this.tmp_stop.Location = new System.Drawing.Point(278, 19);
            this.tmp_stop.Name = "tmp_stop";
            this.tmp_stop.Size = new System.Drawing.Size(108, 37);
            this.tmp_stop.TabIndex = 11;
            this.tmp_stop.Text = "Stop";
            this.tmp_stop.UseVisualStyleBackColor = false;
            this.tmp_stop.Click += new System.EventHandler(this.tmp_stop_Click);
            // 
            // tmp_start
            // 
            this.tmp_start.BackColor = System.Drawing.Color.Green;
            this.tmp_start.Location = new System.Drawing.Point(68, 19);
            this.tmp_start.Name = "tmp_start";
            this.tmp_start.Size = new System.Drawing.Size(116, 37);
            this.tmp_start.TabIndex = 10;
            this.tmp_start.Text = "Start";
            this.tmp_start.UseVisualStyleBackColor = false;
            this.tmp_start.Click += new System.EventHandler(this.tmp_start_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.tmp_start);
            this.groupBox1.Controls.Add(this.tmp_stop);
            this.groupBox1.Location = new System.Drawing.Point(61, 238);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(409, 76);
            this.groupBox1.TabIndex = 12;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Temperature";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.cps_start);
            this.groupBox2.Controls.Add(this.cps_stop);
            this.groupBox2.Location = new System.Drawing.Point(61, 127);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(409, 78);
            this.groupBox2.TabIndex = 13;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Compressor";
            this.groupBox2.Enter += new System.EventHandler(this.groupBox2_Enter);
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.label1);
            this.groupBox3.Controls.Add(this.SelectPort);
            this.groupBox3.Controls.Add(this.Baudrate);
            this.groupBox3.Controls.Add(this.btn_connect);
            this.groupBox3.Controls.Add(this.label2);
            this.groupBox3.Location = new System.Drawing.Point(30, 12);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(476, 66);
            this.groupBox3.TabIndex = 14;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Setup Serial Port ";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(15, 32);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(56, 13);
            this.label1.TabIndex = 6;
            this.label1.Text = "SelectPort";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(585, 348);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.Name = "Form1";
            this.Text = "ChillerControl";
            this.groupBox1.ResumeLayout(false);
            this.groupBox2.ResumeLayout(false);
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btn_connect;
        private System.Windows.Forms.ComboBox SelectPort;
        private System.Windows.Forms.ComboBox Baudrate;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button cps_start;
        private System.Windows.Forms.Button cps_stop;
        private System.Windows.Forms.Button tmp_stop;
        private System.Windows.Forms.Button tmp_start;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Label label1;
    }
}

