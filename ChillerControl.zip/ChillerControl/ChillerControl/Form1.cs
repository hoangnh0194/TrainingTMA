﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO.Ports;

namespace ChillerControl
{
    public partial class Form1 : Form
    {
        bool isConnected = false;
        String[] ports;
        SerialPort port;
        public Form1()
        {
            InitializeComponent();
            disableControls();
            getAvailableComPorts();

            foreach (string port in ports)
            {
                SelectPort.Items.Add(port);
                Console.WriteLine(port);
                if (ports[0] != null)
                {
                    SelectPort.SelectedItem = ports[0];
                }
            }
        }

        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void cps_start_Click(object sender, EventArgs e)
        {
            if (isConnected)
            {
                port.Write("#TEXT" + "Start compressor" + "#\n");
            }
        }

        private void cps_stop_Click(object sender, EventArgs e)
        {
            if (isConnected)
            {
                port.Write("#TEXT" + "Stop compressor" + "#\n");
            }
        }

        private void btn_connect_Click(object sender, EventArgs e)
        {
            if (!isConnected)
            {
                connectToArduino();
            }
            else
            {
                disconnectFromArduino();
            }
        }
        private void tmp_start_Click(object sender, EventArgs e)
        {
            if (isConnected)
            {
                port.Write("#TEXT" + "Start temperature" + "#\n");
            }
        }

        private void tmp_stop_Click(object sender, EventArgs e)
        {
            if (isConnected)
            {
                port.Write("#TEXT" + "Stop temperature" + "#\n");
            }
        }
        void getAvailableComPorts()
        {
            if ( SerialPort.GetPortNames() !=null )
            {
                ports = SerialPort.GetPortNames();
            }
            else { }
        }

        private void enableControls()
        {

            cps_start.Enabled = true;
            cps_stop.Enabled = true;
            tmp_start.Enabled = true;
            tmp_stop.Enabled = true;

        }

        private void disableControls()
        {

            cps_start.Enabled = false;
            cps_stop.Enabled = false;
            tmp_start.Enabled = false;
            tmp_stop.Enabled = false;

        }

        private void resetDefaults()
        {

        }

        private void connectToArduino()
        {
            isConnected = true;
            string selectedPort = SelectPort.GetItemText(SelectPort.SelectedItem);
            port = new SerialPort(selectedPort, 9600, Parity.None, 8, StopBits.One);
            port.Open();
            port.Write("#STAR\n");
            btn_connect.Text = "Disconnect";
            enableControls();
        }

        private void disconnectFromArduino()
        {
            isConnected = false;
            port.Write("#STOP\n");
            port.Close();
            btn_connect.Text = "Connect";
            disableControls();
            resetDefaults();
        }

        private void groupBox2_Enter(object sender, EventArgs e)
        {

        }


    }
}
